package Backend;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Map;

public class FoodItem implements Serializable {

    private static final String FOOD_FILE = "fooditems.dat";

    private String name;
    private double price;
    private int quantity;

    public FoodItem(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // --- Standard Getters/Setters ---
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    @Override
    public String toString() {
        return name + " (PKR " + String.format("%.2f", price) + "), Qty: " + quantity;
    }

    // --- Static CRUD methods for file storage ---

    public static List<FoodItem> loadFoodItems() {
        File file = new File(FOOD_FILE);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = in.readObject();
            if (obj instanceof List) {
                return (List<FoodItem>) obj;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public static void saveFoodItems(List<FoodItem> items) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FOOD_FILE))) {
            out.writeObject(items);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addFoodItem(FoodItem item) {
        List<FoodItem> items = loadFoodItems();
        items.add(item);
        saveFoodItems(items);
    }

    public static boolean updateFoodItem(String oldName, FoodItem updated) {
        List<FoodItem> items = loadFoodItems();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getName().equals(oldName)) {
                items.set(i, updated);
                saveFoodItems(items);
                return true;
            }
        }
        return false;
    }

    public static void updateQuantities(Map<FoodItem, Integer> orderedItems) {
        List<FoodItem> current = loadFoodItems();
        List<FoodItem> updated = new ArrayList<>();
        for (FoodItem item : current) {
            int orderedQty = 0;
            for (FoodItem ordered : orderedItems.keySet()) {
                if (ordered.getName().equals(item.getName())) {
                    orderedQty = orderedItems.get(ordered);
                    break;
                }
            }
            int newQty = item.getQuantity() - orderedQty;
            if (newQty > 0) {
                item.setQuantity(newQty);
                updated.add(item);
            }
            // else, don't add it (removes from menu)
        }
        saveFoodItems(updated);
    }
    public static boolean deleteFoodItem(String name) {
        List<FoodItem> items = loadFoodItems();
        Iterator<FoodItem> iter = items.iterator();
        boolean found = false;
        while (iter.hasNext()) {
            if (iter.next().getName().equals(name)) {
                iter.remove();
                found = true;
            }
        }
        if (found) saveFoodItems(items);
        return found;
    }
}