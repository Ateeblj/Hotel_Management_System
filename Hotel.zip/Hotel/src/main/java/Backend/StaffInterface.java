package Backend;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

class Role implements Serializable {
    private String name;
    private int availableCount;

    public Role(String name, int availableCount) {
        this.name = name;
        this.availableCount = availableCount;
    }

    public String getName() {
        return name;
    }

    public int getAvailableCount() {
        return availableCount;
    }

    public void setAvailableCount(int availableCount) {
        this.availableCount = availableCount;
    }

    public void incrementAvailableCount() {
        this.availableCount++;
    }

    public void decrementAvailableCount() {
        this.availableCount--;
    }
}

public class StaffInterface implements Serializable {
    private List<Staff> staffList;
    private transient Scanner scanner;
    private List<Role> availableStaffRoles;
    private List<Task> taskList;

    // Constructor
    public StaffInterface(List<Staff> staffList, List<Role> availableStaffRoles) {
        this.staffList = staffList;
        this.availableStaffRoles = availableStaffRoles;
        this.scanner = new Scanner(System.in);
        this.taskList = loadTasks();
        if (this.taskList == null) {
            this.taskList = new ArrayList<>();
        }
    }

    // Authenticate Staff
    public boolean authenticateStaff(Manager manager, String password) {
        return manager.validateStaffPassword(password);
    }

    // Display Staff Menu
    public void displayStaffMenu(Manager manager) {
        while (true) {
            System.out.println("\n--- Staff Interface ---");
            System.out.println("1. Add New Staff");
            System.out.println("2. View Staff Details");
            System.out.println("3. Update Staff Status / Delete Staff");
            System.out.println("4. View Fee Slips (Manager Only)");
            System.out.println("5. Reset System (Manager Only)");
            System.out.println("6. Show Client Information (Manager Only)");
            System.out.println("7. Show Clients Feedback (Manager Only)");
            System.out.println("8. Task Assignment & Tracking (Manager Only)");
            System.out.println("9. Staff Task Panel");
            System.out.println("10. Exit");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addStaff();
                    break;
                case 2:
                    viewStaffDetails();
                    break;
                case 3:
                    updateStaffStatus();
                    break;
                case 4:
                    viewFeeSlips(manager);
                    break;
                case 5:
                    resetSystem(manager);
                    break;
                case 6:
                    showClientInformation(manager);
                    break;
                case 7:
                    showFeedback(manager);
                    break;
                case 8:
                    managerTaskPanel();
                    break;
                case 9:
                    staffTaskPanel();
                    break;
                case 10:
                    System.out.println("Exiting Manager Interface. Goodbye!");
                    saveTasks();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Add New Staff
    private void addStaff() {
        String staffName;
        String role;
        String category = "Other";
        while (true) {
            System.out.print("Enter Staff Name: ");
            staffName = scanner.nextLine().trim();
            if (staffName.isEmpty()) {
                System.out.println("Staff name cannot be empty. Please enter a valid name.");
            } else if (!staffName.matches("^[a-zA-Z\\s]+$")) {
                System.out.println("Staff name can only contain letters and spaces. Please enter a valid name.");
            } else {
                break;
            }
        }

        while (true) {
            System.out.print("Enter Role: ");
            role = scanner.nextLine().trim().toLowerCase();
            if (role.isEmpty()) {
                System.out.println("Role cannot be empty. Please enter a valid role.");
            } else {
                break;
            }
        }

        if (role.contains("front desk")) {
            category = "Front Desk";
        } else if (role.contains("housekeeping")) {
            category = "Housekeeping";
        } else if (role.contains("maintenance")) {
            category = "Maintenance";
        } else {
            category = "Other";
        }

        Staff newStaff = new Staff(staffName, role, "New");
        staffList.add(newStaff);
        System.out.println("New staff member added successfully. Category: " + category);
    }

    // View Staff Details
    private void viewStaffDetails() {
        System.out.println("\n--- Staff Details ---");
        if (staffList.isEmpty()) {
            System.out.println("No staff members to display.");
            return;
        }
        boolean found = false;
        for (Staff staff : staffList) {
            if (!staff.getStatus().equalsIgnoreCase("Initial")) {
                System.out.println("Name: " + staff.getName());
                System.out.println("Role: " + staff.getRole());
                System.out.println("Status: " + staff.getStatus());
                System.out.println("----------------------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No staff members to display (excluding initial setup staff).");
        }
    }

    // Update Staff Status / Delete Staff
    private void updateStaffStatus() {
        if (staffList.isEmpty()) {
            System.out.println("No staff members to update or delete.");
            return;
        }
        System.out.print("Enter Staff Name: ");
        String staffName = scanner.nextLine();

        for (int i = 0; i < staffList.size(); i++) {
            Staff staff = staffList.get(i);
            if (staff.getName().equalsIgnoreCase(staffName)) {
                System.out.println("Current Status: " + staff.getStatus());
                System.out.println("Options:");
                System.out.println("1. Update Status");
                System.out.println("2. Delete Staff");
                System.out.print("Choose an option: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        System.out.print("Enter New Status (New / Active / Left): ");
                        String newStatus = scanner.nextLine();
                        staff.setStatus(newStatus);
                        // On "Left", unassign tasks
                        if (newStatus.equalsIgnoreCase("Left")) {
                            unassignTasksOfStaff(staffName);
                        }
                        System.out.println("Staff status updated successfully.");
                        return;
                    case 2:
                        staffList.remove(i);
                        unassignTasksOfStaff(staffName);
                        System.out.println("Staff member deleted successfully.");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        return;
                }
            }
        }
        System.out.println("Staff name not found.");
    }

    // Unassign incomplete tasks when staff leaves/is deleted
    private void unassignTasksOfStaff(String staffName) {
        boolean found = false;
        for (Task t : taskList) {
            if (t.getAssignedTo().equalsIgnoreCase(staffName) && !t.getStatus().equalsIgnoreCase("Completed")) {
                t.setAssignedTo("Unassigned");
                t.setStatus("Pending");
                t.appendComment("Task unassigned on staff departure.");
                found = true;
            }
        }
        if (found) {
            saveTasks();
            System.out.println("All incomplete tasks for " + staffName + " are now unassigned.");
        }
    }

    // View Fee Slips (Manager Only) - Shows all slips including refund/cancellation
    private void viewFeeSlips(Manager manager) {
        System.out.print("Enter Manager Password: ");
        String managerPassword = scanner.nextLine();

        if (!manager.validateManagerPassword(managerPassword)) {
            System.out.println("❌ Incorrect password. Access denied.");
            return;
        }

        System.out.println("\n--- Fee Slips ---");
        File file = new File("fee_slips.txt");
        if (!file.exists()) {
            System.out.println("No fee slips found.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean anySlip = false;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    System.out.println(line);
                    anySlip = true;
                }
            }
            if (!anySlip) {
                System.out.println("No fee slips found.");
            }
        } catch (IOException e) {
            System.out.println("Error reading fee slips: " + e.getMessage());
        }
    }

    // Reset System (Manager Only)
    private void resetSystem(Manager manager) {
        System.out.print("Enter Manager Password to Reset System: ");
        String managerPassword = scanner.nextLine();

        if (manager.validateManagerPassword(managerPassword)) {
            System.out.println("\n⚠️ WARNING: This operation will delete all stored data and restart the system.");
            System.out.print("Are you sure you want to proceed? (yes/no): ");
            String confirmation = scanner.nextLine();

            if (confirmation.equalsIgnoreCase("yes")) {
                staffList.clear();
                taskList.clear();
                deleteFile("system_data.dat");
                deleteFile("client_data.dat");
                deleteFile("fee_slips.txt");
                deleteFile("feedback_data.dat");
                deleteFile("task_data.dat");
                System.out.println("🔄 System data deleted successfully. Restarting customization process...");
                System.exit(0);
            } else {
                System.out.println("❌ Reset system operation cancelled.");
            }
        } else {
            System.out.println("❌ Incorrect password. Access denied.");
        }
    }

    private void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.exists() && file.delete()) {
            System.out.println("Deleted file: " + fileName);
        } else {
            System.out.println("File not found or could not be deleted: " + fileName);
        }
    }

    private void showClientInformation(Manager manager) {
        System.out.print("Enter Manager Password to View Client Information: ");
        String managerPassword = scanner.nextLine();

        if (!manager.validateManagerPassword(managerPassword)) {
            System.out.println("❌ Incorrect password. Access denied.");
            return;
        }

        System.out.println("\n--- Client Information ---");
        File clientFile = new File("client_data.dat");
        if (!clientFile.exists()) {
            System.out.println("No client information found.");
            return;
        }

        List<Client> allClients = new ArrayList<>();
        boolean hasData = false;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(clientFile))) {
            while (true) {
                try {
                    Client client = (Client) in.readObject();
                    allClients.add(client);
                    hasData = true;
                } catch (EOFException e) {
                    break;
                }
            }
            if (hasData) {
                System.out.println("\n--- All Client Records ---");
                for (Client client : allClients) {
                    System.out.println("Name: " + client.getName());
                    System.out.println("Phone: " + client.getPhoneNumber());
                    System.out.println("Address: " + client.getAddress());
                    System.out.println("Email: " + client.getEmail());
                    System.out.printf("CNIC: %s\n", client.getCnic());
                    System.out.println("----------------------------");
                }
            } else {
                System.out.println("No client records found in file.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❌ Error reading client information: " + e.getMessage());
        }
    }

    private void showFeedback(Manager manager) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter Manager Password: ");
        String managerPassword = scan.nextLine();

        if (!manager.validateManagerPassword(managerPassword)) {
            System.out.println("❌ Incorrect password. Access denied.");
            return;
        }

        if (manager.validateManagerPassword(managerPassword)) {
            Feedback.displayFeedbackRecords();
        }
    }

    // ===================== TASK MANAGEMENT =====================

    // -------- MANAGER TASK PANEL --------
    private void managerTaskPanel() {
        while (true) {
            System.out.println("\n--- Manager Task Assignment & Tracking ---");
            System.out.println("1. Assign New Task");
            System.out.println("2. View All Tasks");
            System.out.println("3. Filter Tasks");
            System.out.println("4. View/Assign Unassigned Tasks");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input.");
                scanner.next();
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    assignTask();
                    break;
                case 2:
                    viewAllTasks(taskList);
                    break;
                case 3:
                    filterTasksMenu();
                    break;
                case 4:
                    viewUnassignedTasks();
                    break;
                case 5:
                    saveTasks();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // Assign new task
    private void assignTask() {
        System.out.println("\n--- Assign New Task ---");
        System.out.print("Enter Task Description: ");
        String description = scanner.nextLine().trim();

        // Choose Department (optional, can be blank)
        System.out.print("Enter Department (optional): ");
        String department = scanner.nextLine().trim();

        // Choose staff
        String assignedTo = chooseStaffForTask(department);

        // Set priority
        String priority = "";
        while (true) {
            System.out.print("Set Priority (Low/Medium/High): ");
            priority = scanner.nextLine().trim();
            if (priority.equalsIgnoreCase("Low") || priority.equalsIgnoreCase("Medium") || priority.equalsIgnoreCase("High")) {
                break;
            } else {
                System.out.println("Invalid priority. Please enter Low, Medium, or High.");
            }
        }

        // Set due date
        LocalDate dueDate = null;
        while (true) {
            System.out.print("Enter Due Date (yyyy-MM-dd) or leave blank: ");
            String dateInput = scanner.nextLine().trim();
            if (dateInput.isEmpty()) {
                break;
            }
            try {
                dueDate = LocalDate.parse(dateInput, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                break;
            } catch (Exception e) {
                System.out.println("Invalid date format.");
            }
        }

        Task task = new Task(description, assignedTo, priority, dueDate, department.isEmpty() ? null : department);
        taskList.add(task);
        saveTasks();
        System.out.println("Task assigned successfully to " + assignedTo + ".");
    }

    // Helper to choose staff for task assignment
    private String chooseStaffForTask(String department) {
        List<String> eligible = new ArrayList<>();
        for (Staff s : staffList) {
            if (!s.getStatus().equalsIgnoreCase("Left")) {
                if (department == null || department.isEmpty() || s.getRole().equalsIgnoreCase(department)) {
                    eligible.add(s.getName());
                }
            }
        }
        if (eligible.isEmpty()) {
            System.out.println("No eligible staff. Assigning as Unassigned.");
            return "Unassigned";
        }
        System.out.println("Eligible Staff:");
        for (int i = 0; i < eligible.size(); i++) {
            System.out.println((i + 1) + ". " + eligible.get(i));
        }
        System.out.print("Choose staff number (or 0 for Unassigned): ");
        int idx = -1;
        while (true) {
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input.");
                scanner.next();
                continue;
            }
            idx = scanner.nextInt();
            scanner.nextLine();
            if (idx == 0) return "Unassigned";
            if (idx > 0 && idx <= eligible.size()) return eligible.get(idx - 1);
            System.out.print("Invalid option. Try again: ");
        }
    }

    // View all tasks
    private void viewAllTasks(List<Task> tasks) {
        if (tasks.isEmpty()) {
            System.out.println("No tasks found.");
            return;
        }
        System.out.println("\n--- All Tasks ---");
        int count = 1;
        for (Task t : tasks) {
            System.out.println("Task #" + count++);
            System.out.println(t);
            System.out.println("-------------------");
        }
    }

    // Filter tasks
    private void filterTasksMenu() {
        System.out.println("\n--- Filter Tasks ---");
        System.out.println("1. By Staff");
        System.out.println("2. By Status");
        System.out.println("3. By Priority");
        System.out.println("4. By Department");
        System.out.println("5. By Due Date (Before)");
        System.out.println("6. By Due Date (After)");
        System.out.println("7. Back");
        System.out.print("Choose: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Invalid input.");
            scanner.next();
            return;
        }
        int choice = scanner.nextInt();
        scanner.nextLine();

        List<Task> filtered = new ArrayList<>();
        switch (choice) {
            case 1:
                System.out.print("Enter Staff name: ");
                String staffName = scanner.nextLine();
                for (Task t : taskList) {
                    if (t.getAssignedTo().equalsIgnoreCase(staffName)) filtered.add(t);
                }
                break;
            case 2:
                System.out.print("Enter Status (Pending/In Progress/Completed): ");
                String status = scanner.nextLine();
                for (Task t : taskList) {
                    if (t.getStatus().equalsIgnoreCase(status)) filtered.add(t);
                }
                break;
            case 3:
                System.out.print("Enter Priority (Low/Medium/High): ");
                String priority = scanner.nextLine();
                for (Task t : taskList) {
                    if (t.getPriority().equalsIgnoreCase(priority)) filtered.add(t);
                }
                break;
            case 4:
                System.out.print("Enter Department: ");
                String dept = scanner.nextLine();
                for (Task t : taskList) {
                    if (t.getDepartment() != null && t.getDepartment().equalsIgnoreCase(dept)) filtered.add(t);
                }
                break;
            case 5:
                System.out.print("Enter Date (yyyy-MM-dd): ");
                String before = scanner.nextLine();
                try {
                    LocalDate beforeDate = LocalDate.parse(before, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    for (Task t : taskList) {
                        if (t.getDueDate() != null && t.getDueDate().isBefore(beforeDate)) filtered.add(t);
                    }
                } catch (Exception e) {
                    System.out.println("Invalid date format.");
                }
                break;
            case 6:
                System.out.print("Enter Date (yyyy-MM-dd): ");
                String after = scanner.nextLine();
                try {
                    LocalDate afterDate = LocalDate.parse(after, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    for (Task t : taskList) {
                        if (t.getDueDate() != null && t.getDueDate().isAfter(afterDate)) filtered.add(t);
                    }
                } catch (Exception e) {
                    System.out.println("Invalid date format.");
                }
                break;
            case 7:
            default:
                return;
        }
        viewAllTasks(filtered);
    }

    // View and assign unassigned tasks
    private void viewUnassignedTasks() {
        List<Task> unassigned = new ArrayList<>();
        for (Task t : taskList) {
            if (t.getAssignedTo().equalsIgnoreCase("Unassigned")) unassigned.add(t);
        }
        if (unassigned.isEmpty()) {
            System.out.println("No unassigned tasks.");
            return;
        }
        System.out.println("\n--- Unassigned Tasks ---");
        int i = 1;
        for (Task t : unassigned) {
            System.out.println("Task #" + i++);
            System.out.println(t);
            System.out.println("-------------------");
        }
        System.out.print("Do you want to assign tasks now? (yes/no): ");
        String ans = scanner.nextLine();
        if (ans.equalsIgnoreCase("yes")) {
            for (Task t : unassigned) {
                System.out.println("Assigning Task: " + t.getDescription());
                String assignedTo = chooseStaffForTask(t.getDepartment());
                t.setAssignedTo(assignedTo);
                saveTasks();
                System.out.println("Task assigned to " + assignedTo + ".");
            }
        }
    }

    // -------- STAFF TASK PANEL --------
    private void staffTaskPanel() {
        System.out.print("Enter your Staff Name: ");
        String staffName = scanner.nextLine();
        boolean exists = false;
        for (Staff s : staffList) {
            if (s.getName().equalsIgnoreCase(staffName) && !s.getStatus().equalsIgnoreCase("Left")) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            System.out.println("Staff name not found or staff has left.");
            return;
        }
        while (true) {
            System.out.println("\n--- Staff Task Panel ---");
            System.out.println("1. View My Tasks");
            System.out.println("2. Update Task Status");
            System.out.println("3. Add/View Comments");
            System.out.println("4. Back");
            System.out.print("Choose option: ");
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input.");
                scanner.next();
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    showTasksOfStaff(staffName);
                    break;
                case 2:
                    updateTaskStatusByStaff(staffName);
                    break;
                case 3:
                    addOrViewComments(staffName);
                    break;
                case 4:
                    saveTasks();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // Show tasks assigned to staff
    private void showTasksOfStaff(String staffName) {
        List<Task> myTasks = new ArrayList<>();
        for (Task t : taskList) {
            if (t.getAssignedTo().equalsIgnoreCase(staffName)) {
                myTasks.add(t);
            }
        }
        if (myTasks.isEmpty()) {
            System.out.println("No tasks assigned to you.");
            return;
        }
        System.out.println("Your Tasks:");
        int i = 1;
        for (Task t : myTasks) {
            System.out.println("Task #" + i++);
            System.out.println(t);
            System.out.println("-------------------");
        }
    }

    // Update the status of a staff's task
    private void updateTaskStatusByStaff(String staffName) {
        List<Task> myTasks = new ArrayList<>();
        for (Task t : taskList) {
            if (t.getAssignedTo().equalsIgnoreCase(staffName) && !t.getStatus().equalsIgnoreCase("Completed")) {
                myTasks.add(t);
            }
        }
        if (myTasks.isEmpty()) {
            System.out.println("No updatable tasks assigned to you.");
            return;
        }
        System.out.println("Select Task to Update:");
        for (int i = 0; i < myTasks.size(); i++) {
            System.out.println((i + 1) + ". " + myTasks.get(i).getDescription() + " (Current Status: " + myTasks.get(i).getStatus() + ")");
        }
        int idx = -1;
        while (true) {
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input.");
                scanner.next();
                continue;
            }
            idx = scanner.nextInt();
            scanner.nextLine();
            if (idx > 0 && idx <= myTasks.size()) break;
            System.out.print("Invalid option. Try again: ");
        }
        Task selected = myTasks.get(idx - 1);
        System.out.print("Enter new status (Pending/In Progress/Completed): ");
        String status = scanner.nextLine();
        if (status.equalsIgnoreCase("Pending") || status.equalsIgnoreCase("In Progress") || status.equalsIgnoreCase("Completed")) {
            selected.setStatus(status);
            saveTasks();
            System.out.println("Status updated.");
        } else {
            System.out.println("Invalid status.");
        }
    }

    // Add or view comments on a staff's task
    private void addOrViewComments(String staffName) {
        List<Task> myTasks = new ArrayList<>();
        for (Task t : taskList) {
            if (t.getAssignedTo().equalsIgnoreCase(staffName)) {
                myTasks.add(t);
            }
        }
        if (myTasks.isEmpty()) {
            System.out.println("No tasks assigned to you.");
            return;
        }
        System.out.println("Select Task to Comment/View:");
        for (int i = 0; i < myTasks.size(); i++) {
            System.out.println((i + 1) + ". " + myTasks.get(i).getDescription());
        }
        int idx = -1;
        while (true) {
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input.");
                scanner.next();
                continue;
            }
            idx = scanner.nextInt();
            scanner.nextLine();
            if (idx > 0 && idx <= myTasks.size()) break;
            System.out.print("Invalid option. Try again: ");
        }
        Task selected = myTasks.get(idx - 1);
        System.out.println("Current Comments:");
        if (selected.getComments() == null || selected.getComments().isEmpty()) {
            System.out.println("No comments yet.");
        } else {
            System.out.println(selected.getComments());
        }
        System.out.print("Add a new comment? (yes/no): ");
        String ans = scanner.nextLine();
        if (ans.equalsIgnoreCase("yes")) {
            System.out.print("Enter your comment: ");
            String comment = scanner.nextLine();
            selected.appendComment("[" + staffName + " @ " + LocalDate.now() + "]: " + comment);
            saveTasks();
            System.out.println("Comment added.");
        }
    }

    // ---------- TASK DATA SERIALIZATION ----------
    private void saveTasks() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("task_data.dat"))) {
            out.writeObject(taskList);
        } catch (Exception e) {
            System.out.println("❌ Error saving task data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private List<Task> loadTasks() {
        File file = new File("task_data.dat");
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Task>) in.readObject();
        } catch (Exception e) {
            System.out.println("❌ Error loading task data: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}