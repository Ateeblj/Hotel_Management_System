package Backend;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for saving and loading Client objects.
 * Handles persistence of client booking information.
 */
public class ClientFileUtil {

    private static final String CLIENT_FILE = "client_data.dat";

    /**
     * Loads all clients from the file.
     * @return List of clients, or empty if none found or error occurs.
     */
    @SuppressWarnings("unchecked")
    public static List<Client> loadClients() {
        File file = new File(CLIENT_FILE);
        if (!file.exists()) {
            System.out.println("❗ Client file not found. Returning empty list.");
            return new ArrayList<>();
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = in.readObject();
            if (obj instanceof List<?>) {
                return (List<Client>) obj;
            } else {
                System.out.println("❗ Data in client file is not a List<Client>. Returning empty list.");
                return new ArrayList<>();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❗ Error loading client data: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Saves all clients to the file.
     * @param clients List of clients to save.
     */
    public static void saveClients(List<Client> clients) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(CLIENT_FILE))) {
            out.writeObject(clients);
            System.out.println("✅ Client data saved successfully.");
        } catch (IOException e) {
            System.out.println("❗ Error saving client data: " + e.getMessage());
        }
    }

    /**
     * Adds a new client to the file by loading the current list,
     * appending the new client, and saving the updated list.
     * @param client The client to add.
     */
    public static void addClient(Client client) {
        List<Client> clients = loadClients();
        clients.add(client);
        saveClients(clients);
    }

    /**
     * Deletes a client from the file based on unique identifier (e.g., cnic or room).
     * @param identifierValue The unique identifier of the client (e.g. cnic).
     * @return true if a client was deleted, false otherwise.
     */
    public static boolean deleteClientByCnic(String identifierValue) {
        List<Client> clients = loadClients();
        boolean removed = clients.removeIf(c -> c.getCnic().equals(identifierValue));
        if (removed) {
            saveClients(clients);
            System.out.println("✅ Client with CNIC " + identifierValue + " deleted.");
        } else {
            System.out.println("❗ No client found with CNIC " + identifierValue + ".");
        }
        return removed;
    }

    /**
     * Updates a client in the file based on unique identifier (CNIC).
     * @param cnic   The CNIC of the client to update.
     * @param edited The client object with updated values.
     * @return true if a client was updated, false otherwise.
     */
    public static boolean updateClient(String cnic, Client edited) {
        List<Client> clients = loadClients();
        boolean updated = false;
        for (int i = 0; i < clients.size(); i++) {
            if (clients.get(i).getCnic().equals(cnic)) {
                clients.set(i, edited);
                updated = true;
                break;
            }
        }
        if (updated) {
            saveClients(clients);
            System.out.println("✅ Client with CNIC " + cnic + " updated.");
        } else {
            System.out.println("❗ No client found with CNIC " + cnic + ".");
        }
        return updated;
    }

    /**
     * Clears all client data from the file.
     */
    public static void clearAllClients() {
        saveClients(new ArrayList<>());
        System.out.println("🗑️ All client data cleared.");
    }
}