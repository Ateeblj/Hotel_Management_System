package Backend;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Room implements Serializable {
    private static final long serialVersionUID = 1L;

    private String roomNumber;
    private RoomType roomType;
    private BedType bedType;
    private boolean isOccupied;
    private double pricePerNight;
    private LocalDate bookingEndDate; // inclusive: guest checks out the morning *after* this date

    public Room(String roomNumber, RoomType roomType, BedType bedType, double pricePerNight) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.bedType = bedType;
        this.isOccupied = false;
        this.pricePerNight = pricePerNight;
        this.bookingEndDate = null;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public BedType getBedType() {
        return bedType;
    }

    public boolean isOccupied() {
        updateAvailability();
        return isOccupied;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public LocalDate getBookingEndDate() {
        return bookingEndDate;
    }

    public void setAvailable(boolean available) {
        this.isOccupied = !available;
        if (available) {
            this.bookingEndDate = null;
        }
    }

    /**
     * Book the room for a given number of nights, starting from today.
     */
    public void bookRoom(int nights) {
        updateAvailability();
        if (!isOccupied) {
            isOccupied = true;
            bookingEndDate = LocalDate.now().plusDays(nights);
            double totalCost = pricePerNight * nights;
            System.out.println("✅ Room " + roomNumber + " successfully booked for " + nights + " night(s). Total cost: PKR " + totalCost);
        } else {
            System.out.println("❌ Room " + roomNumber + " is already occupied.");
        }
    }

    /**
     * Cancel the booking for this room.
     */
    public void cancelBooking() {
        this.isOccupied = false;
        this.bookingEndDate = null;
        System.out.println("✅ Booking for room " + roomNumber + " has been cancelled.");
    }

    public void checkoutRoom() {
        updateAvailability();
        if (isOccupied) {
            isOccupied = false;
            bookingEndDate = null;
            System.out.println("✅ Room " + roomNumber + " successfully checked out.");
        } else {
            System.out.println("❗ Room " + roomNumber + " is already available.");
        }
    }

    /**
     * Checks if the room's booking period is over and updates its status.
     * Should be called before showing in "View Rooms" or when checking status.
     */
    public void updateAvailability() {
        if (isOccupied && bookingEndDate != null && !bookingEndDate.isAfter(LocalDate.now())) {
            // If today is after or the same as bookingEndDate, make room available
            isOccupied = false;
            bookingEndDate = null;
        }
    }

    public void displayRoomDetails() {
        updateAvailability();
        String status = isOccupied ? "Occupied until " + bookingEndDate : "Available";
        System.out.printf("🛏️ Room %s | Type: %s (%s Bed) | Status: %s | Price: PKR %.2f%n",
                roomNumber, roomType, bedType, status, pricePerNight);
    }

    public double getBasePrice() {
        return getPricePerNight();
    }

    @Override
    public String toString() {
        return roomNumber + " - " + roomType + " - " + bedType + " - " +
                (isOccupied ? "Occupied" : "Available") +
                (bookingEndDate != null ? " until " + bookingEndDate : "");
    }
}