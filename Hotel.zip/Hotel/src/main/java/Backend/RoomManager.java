package Backend;

import java.io.*;
import java.util.*;
import java.time.LocalDate;

public class RoomManager {
    private static final String ROOMS_FILE = "rooms.dat";

    public static List<Room> loadRoomsFromFile() {
        File file = new File(ROOMS_FILE);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Room>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static void saveRoomsToFile(List<Room> rooms) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ROOMS_FILE))) {
            oos.writeObject(rooms);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addRoom(Room newRoom) {
        List<Room> rooms = loadRoomsFromFile();
        rooms.add(newRoom);
        saveRoomsToFile(rooms);
    }

    public static boolean bookRoom(String roomNumber, int nights) {
        List<Room> rooms = loadRoomsFromFile();
        for (Room r : rooms) {
            r.updateAvailability();
            if (r.getRoomNumber().equals(roomNumber) && !r.isOccupied()) {
                r.bookRoom(nights);
                saveRoomsToFile(rooms);
                return true;
            }
        }
        return false;
    }

    public static List<Room> getAvailableRooms() {
        List<Room> rooms = loadRoomsFromFile();
        List<Room> available = new ArrayList<>();
        for (Room r : rooms) {
            r.updateAvailability();
            if (!r.isOccupied()) available.add(r);
        }
        saveRoomsToFile(rooms); // persist any status changes
        return available;
    }

    // === NEW METHOD FOR CANCELLING ROOM BOOKING ===
    public static boolean cancelBooking(String roomNumber) {
        List<Room> rooms = loadRoomsFromFile();
        boolean changed = false;
        for (Room r : rooms) {
            if (r.getRoomNumber().equals(roomNumber) && r.isOccupied()) {
                r.cancelBooking();
                changed = true;
                break;
            }
        }
        if (changed) {
            saveRoomsToFile(rooms);
        }
        return changed;
    }



}