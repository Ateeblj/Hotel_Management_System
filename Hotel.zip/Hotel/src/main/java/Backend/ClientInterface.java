package Backend;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 * Provides the console-based interface for hotel clients to
 * view rooms, book rooms, order food, submit feedback, and cancel bookings.
 */
public class ClientInterface {
    private List<Room> rooms;

    private Feedback feedbackSystem;
    private Scanner scanner;
    double amount = 0;
    String bookedRoomNumber;

    public double amount1() {
        return amount;
    }

    public ClientInterface(List<Room> rooms, Feedback feedbackSystem) {
        this.rooms = rooms;

        this.feedbackSystem = feedbackSystem;
        this.scanner = new Scanner(System.in);
    }

    public void displayClientMenu() {
        while (true) {
            System.out.println("\n--- Client Interface ---");
            System.out.println("1. View Available Rooms");
            System.out.println("2. Book a Room");
            System.out.println("3. Order Food");
            System.out.println("4. Submit Feedback");
            System.out.println("5. Cancel Room Booking");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 -> viewAvailableRooms();
                case 2 -> bookRoom();
                case 3 -> orderFood();
                case 4 -> submitFeedback();
                case 5 -> cancelRoomBooking();
                case 6 -> {
                    System.out.println("Exiting Client Interface. Thank you!");
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public void viewAvailableRooms() {
        System.out.println("\n--- Available Rooms ---");
        boolean roomsAvailable = false;
        for (Room room : rooms) {
            if (!room.isOccupied() || (room.getBookingEndDate() != null && room.getBookingEndDate().isBefore(LocalDate.now()))) {
                room.displayRoomDetails();
                roomsAvailable = true;
            }
        }
        if (!roomsAvailable) {
            System.out.println("No available rooms at the moment.");
        }
    }

    public void bookRoom() {
        System.out.print("Enter Number of Rooms to Book: ");
        int numberOfRooms = scanner.nextInt();
        scanner.nextLine();

        if (numberOfRooms <= 0) {
            System.out.println("❌ Invalid number of rooms. Booking failed.");
            return;
        }

        String name = getValidName();
        String cnic = getValidCnic();
        String address = getValidAddress();
        String phoneNumber = getValidPhoneNumber();
        String email = getValidEmail();

        double totalCost = 0;
        StringBuilder bookedRooms = new StringBuilder();

        for (int i = 0; i < numberOfRooms; i++) {
            System.out.print("Enter Room Number to Book: ");
            String roomNumber = scanner.nextLine();

            boolean roomFound = false;

            for (Room room : rooms) {
                if (room.getRoomNumber().equals(roomNumber) && !room.isOccupied()) {
                    System.out.print("Enter number of nights for this room: ");
                    int nights = scanner.nextInt();
                    scanner.nextLine();

                    double roomCost = nights * room.getPricePerNight();
                    totalCost += roomCost;
                    bookedRooms.append(roomNumber).append(", ");

                    room.bookRoom(nights);

                    // Store booking info in client object for cancellation feature
                    // Corrected Client constructor usage
                    Client client = new Client(name, cnic, phoneNumber, email, roomNumber, address, nights, roomCost);
                    client.bookRoom(roomNumber, LocalDate.now().plusDays(nights));
                    saveClientData(client);

                    roomFound = true;
                    break;
                }
            }

            if (!roomFound) {
                System.out.println("❌ Room not found or already occupied. Please try again.");
                i--;
            }
        }

        System.out.printf("Total Cost for %d Room(s): PKR %.2f\n", numberOfRooms, totalCost);
        System.out.print("Enter Cash Payment: PKR ");
        double payment = scanner.nextDouble();
        scanner.nextLine();

        if (payment >= totalCost) {
            double change = payment - totalCost;
            System.out.printf("Booking Confirmed! Change: PKR %.2f\n", change);

            // Save master booking client for fee slip
            Client masterClient = new Client(name, cnic, phoneNumber, email, bookedRooms.toString(), address, 0, payment);
            generateFeeSlip(masterClient, null, totalCost, "Room Booking for Rooms: " + bookedRooms.toString().trim());
        } else {
            System.out.println("❌ Insufficient payment. Booking failed.");
        }
    }

    public void orderFood() {


        System.out.print("Enter Your Name: ");
        String clientName = scanner.nextLine();

        System.out.print("Enter Your Room Number: ");
        String roomNumber = scanner.nextLine();

        Room clientRoom = null;
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
                clientRoom = room;
                break;
            }
        }

        if (clientRoom == null) {
            System.out.println("❌ Invalid room number. Please try again.");
            return;
        }

        double totalCost = 0;
        StringBuilder orderDescription = new StringBuilder();

        while (true) {
            System.out.print("Enter Food Item Name: ");
            String foodItemName = scanner.nextLine();

            System.out.print("Enter Quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine();

            boolean itemFound = false;
            for (FoodItem item : Manager.getFoodItems()) {
                if (item.getName().equalsIgnoreCase(foodItemName.trim())) {
                    double itemCost = item.getPrice() * quantity;
                    totalCost += itemCost;

                    orderDescription.append(
                            String.format(
                                    "%s x%d (PKR %.2f)%n",
                                    item.getName(),
                                    quantity,
                                    itemCost
                            )
                    );

                    itemFound = true;
                    break;
                }
            }
            if (!itemFound) {
                // Handle item not found, e.g.
                // orderDescription.append("Item not found: ").append(foodItemName).append('\n');
            }

            if (!itemFound) {
                System.out.println("Invalid food item. Please try again.");
            } else {
                System.out.print("Do you want to order anything else? (yes/no): ");
                String response = scanner.nextLine();
                if (!response.equalsIgnoreCase("yes")) {
                    break;
                }
            }
        }

        System.out.printf("Total Cost: PKR %.2f\n", totalCost);
        System.out.print("Enter Cash Payment: PKR ");
        double payment = scanner.nextDouble();
        scanner.nextLine();

        if (payment >= totalCost) {
            double change = payment - totalCost;
            System.out.printf("Order Confirmed! Change: PKR %.2f\n", change);

            generateFeeSlip(
                    new Client(clientName, null, null, null, null, null, 0, payment),
                    clientRoom,
                    totalCost,
                    "Food Order:\n" + orderDescription.toString().trim()
            );
        } else {
            System.out.println("❌ Insufficient payment. Order failed.");
        }
    }

    public void submitFeedback() {
        System.out.print("Enter Your Name: ");
        String clientName = scanner.nextLine();

        System.out.print("Enter Your Room Number: ");
        String roomNumber = scanner.nextLine();

        System.out.print("Enter Your Feedback: ");
        String feedback = scanner.nextLine();

        System.out.print("Enter Rating (1-5): ");
        int rating;
        while (true) {
            rating = scanner.nextInt();
            if (rating >= 1 && rating <= 5) {
                break;
            } else {
                System.out.print("Invalid rating. Please enter a value between 1 and 5: ");
            }
        }
        scanner.nextLine();

        feedbackSystem.collectFeedback(clientName, roomNumber, feedback, rating);
    }

    public void cancelRoomBooking() {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter your room number to cancel: ");
        String roomNumber = scanner.nextLine().trim();

        Room bookedRoom = null;
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber) && room.isOccupied()) {
                bookedRoom = room;
                break;
            }
        }

        if (bookedRoom == null) {
            System.out.println("❌ No such occupied room found.");
            return;
        }

        // Find client from file
        Client client = null;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("client_data.dat"))) {
            while (true) {
                try {
                    Client c = (Client) in.readObject();
                    if (c.getName().equalsIgnoreCase(name) && roomNumber.equals(c.getBookedRoomNumber())) {
                        client = c;
                        break;
                    }
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            // No client data or read error
        }

        if (client == null) {
            System.out.println("❌ No client booking found under your name for this room.");
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDate endDate = bookedRoom.getBookingEndDate();
        long nightsLeft = (endDate != null) ? endDate.toEpochDay() - today.toEpochDay() : 0;
        if (nightsLeft < 0) nightsLeft = 0;
        double refund = nightsLeft * bookedRoom.getPricePerNight();

        bookedRoom.checkoutRoom();

        client.cancelBooking();
        client.setAmount(client.getAmount() + refund);
        saveClientData(client);

        generateCancellationSlip(client, bookedRoom, refund, nightsLeft);

        System.out.printf("✅ Booking cancelled. Refund: PKR %.2f\n", refund);
    }

    /**
     * Save a client booking record using the ClientFileUtil class (preferred).
     */
    private void saveClientData(Client client) {
        try {
            ClientFileUtil.addClient(client);
            System.out.println("Client data saved successfully.");
        } catch (Exception e) {
            System.out.println("❌ Error saving client data: " + e.getMessage());
        }
    }

    private void generateFeeSlip(Client client, Room room, double amount, String description) {
        this.amount = amount;
        String slip = """
                ========= Fee Slip =========
                Date: %s
                Client: %s
                Room: %s
                Description: %s
                Amount: PKR %.2f
                ============================
                """.formatted(
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                client != null ? client.getName() : "N/A",
                room != null ? room.getRoomNumber() : "N/A",
                description,
                amount
        );

        try (FileWriter writer = new FileWriter("fee_slips.txt", true)) {
            writer.write(slip);
            writer.write(System.lineSeparator());
            System.out.println("💾 Fee slip saved successfully.");
        } catch (IOException e) {
            System.out.println("❌ Error saving fee slip: " + e.getMessage());
        }
    }

    private void generateCancellationSlip(Client client, Room room, double refund, long nightsLeft) {
        String slip = """
                ========= Room Cancellation Slip =========
                Date: %s
                Client: %s
                Room: %s
                Refund for %d unused night(s)
                Refund Amount: PKR %.2f
                =========================================
                """.formatted(
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                client != null ? client.getName() : "N/A",
                room != null ? room.getRoomNumber() : "N/A",
                nightsLeft,
                refund
        );

        try (FileWriter writer = new FileWriter("fee_slips.txt", true)) {
            writer.write(slip);
            writer.write(System.lineSeparator());
            System.out.println("💾 Cancellation slip saved successfully.");
        } catch (IOException e) {
            System.out.println("❌ Error saving cancellation slip: " + e.getMessage());
        }
    }

    private String getValidName() {
        while (true) {
            System.out.print("Enter your name (letters and spaces only): ");
            String name = scanner.nextLine();
            if (name.matches("[a-zA-Z\\s]+")) {
                return name;
            } else {
                System.out.println("Invalid name. Please try again.");
            }
        }
    }

    private String getValidCnic() {
        while (true) {
            System.out.print("Enter your CNIC (13 digits without dashes): ");
            String cnic = scanner.nextLine();
            if (cnic.matches("\\d{13}")) {
                return cnic;
            } else {
                System.out.println("Invalid CNIC. Please try again.");
            }
        }
    }

    private String getValidAddress() {
        while (true) {
            System.out.print("Enter your address (letters, numbers, spaces, commas, periods, and dashes only): ");
            String address = scanner.nextLine();
            if (address.matches("[a-zA-Z0-9\\s,.-]+")) {
                return address;
            } else {
                System.out.println("Invalid address. Please try again.");
            }
        }
    }

    private String getValidPhoneNumber() {
        while (true) {
            System.out.print("Enter your phone number (11 digits): ");
            String phoneNumber = scanner.nextLine();
            if (phoneNumber.matches("\\d{11}")) {
                return phoneNumber;
            } else {
                System.out.println("Invalid phone number. Please try again.");
            }
        }
    }

    private String getValidEmail() {
        while (true) {
            System.out.print("Enter your email (format: example@example.com): ");
            String email = scanner.nextLine();
            if (email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")) {
                return email;
            } else {
                System.out.println("Invalid email. Please try again.");
            }
        }
    }
}