package Backend;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class FeeSlipUtil {
    private static final String FEE_SLIP_FILE = "fee_slips.txt";
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static List<FeeSlip> loadFeeSlips() {
        List<FeeSlip> slips = new ArrayList<>();
        File file = new File(FEE_SLIP_FILE);
        if (!file.exists()) return slips;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String clientName = "", roomNumber = "", paymentMethod = "Cash";
            double amountPaid = 0.0;
            LocalDateTime paymentDate = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Date:")) {
                    String dateStr = line.substring(5).trim();
                    try { paymentDate = LocalDateTime.parse(dateStr, dateFormatter); }
                    catch(Exception e) { paymentDate = null; }
                } else if (line.startsWith("Client:")) {
                    clientName = line.substring(7).trim();
                } else if (line.startsWith("Room:")) {
                    roomNumber = line.substring(5).trim();
                } else if (line.startsWith("Amount: PKR")) {
                    try { amountPaid = Double.parseDouble(line.substring(11).trim()); }
                    catch(Exception e) { amountPaid = 0.0; }
                } else if (line.startsWith("Method:")) {
                    paymentMethod = line.substring(7).trim();
                } else if (line.equals("===========================") || line.equals("============================") || line.equals("========================================")) {
                    // End of slip, add if valid
                    if (paymentDate != null && !clientName.isEmpty()) {
                        slips.add(new FeeSlip(clientName, roomNumber, amountPaid, paymentDate, paymentMethod));
                    }
                    // Reset all for next slip
                    clientName = "";
                    roomNumber = "";
                    paymentMethod = "Cash";
                    amountPaid = 0.0;
                    paymentDate = null;
                }
            }
        } catch (Exception e) {
            System.out.println("❗ Error reading fee slips: " + e.getMessage());
        }
        return slips;
    }

    public static void saveFeeSlip(FeeSlip slip) {
        try (PrintWriter out = new PrintWriter(new FileWriter(FEE_SLIP_FILE, true))) {
            out.println("Date: " + dateFormatter.format(slip.getPaymentDate()));
            out.println("Client: " + slip.getClientName());
            out.println("Room: " + slip.getRoomNumber());
            out.println("Amount: PKR " + slip.getAmountPaid());
            out.println("Method: " + slip.getPaymentMethod());
            out.println("===========================");
        } catch (IOException e) {
            System.out.println("❗ Error writing fee slip: " + e.getMessage());
        }
    }
}