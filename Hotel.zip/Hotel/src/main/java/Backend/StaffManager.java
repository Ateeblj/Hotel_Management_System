package Backend;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * StaffManager handles adding, updating, deleting, loading, and saving Staff objects.
 */
public class StaffManager {
    private static final String STAFF_FILE = "staff_data.dat";

    @SuppressWarnings("unchecked")
    public static List<Staff> loadStaff() {
        File file = new File(STAFF_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Staff>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❗ Error loading staff data: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static void saveStaff(List<Staff> staffList) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(STAFF_FILE))) {
            out.writeObject(staffList);
        } catch (IOException e) {
            System.out.println("❗ Error saving staff data: " + e.getMessage());
        }
    }

    public static void addStaff(Staff staff) {
        List<Staff> staffList = loadStaff();
        staffList.add(staff);
        saveStaff(staffList);
    }

    public static void updateStaff(Staff updatedStaff) {
        List<Staff> staffList = loadStaff();
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getId().equals(updatedStaff.getId())) {
                staffList.set(i, updatedStaff);
                saveStaff(staffList);
                return;
            }
        }
        System.out.println("❗ Staff with ID " + updatedStaff.getId() + " not found.");
    }

    public static void deleteStaff(String id) {
        List<Staff> staffList = loadStaff();
        staffList.removeIf(staff -> staff.getId().equals(id));
        saveStaff(staffList);
    }

    public static Staff getStaffById(String id) {
        List<Staff> staffList = loadStaff();
        for (Staff staff : staffList) {
            if (staff.getId().equals(id)) {
                return staff;
            }
        }
        return null;
    }

    public static Staff findStaffByName(String name) {
        List<Staff> staffList = loadStaff();
        for (Staff s : staffList) {
            if (s != null && s.getName() != null && s.getName().equalsIgnoreCase(name)) return s;
        }
        return null;
    }

    public static Staff findStaffByUsernameAndPassword(String username, String password) {
        List<Staff> staffList = loadStaff();
        for (Staff s : staffList) {
            if (s != null &&
                    s.getUsername() != null && s.getPassword() != null && s.getStatus() != null &&
                    s.getUsername().equals(username) &&
                    s.getPassword().equals(password) &&
                    !"Left".equalsIgnoreCase(s.getStatus())) {
                return s;
            }
        }
        return null;
    }


}