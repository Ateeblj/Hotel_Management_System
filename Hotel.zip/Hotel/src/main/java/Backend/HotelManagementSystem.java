package Backend;

import java.io.*;
import java.util.*;

public class HotelManagementSystem implements Serializable {
    private static final long serialVersionUID = 1L;

    private Manager manager;
    private List<Room> rooms;
    private List<Staff> staffList;
    private transient ClientInterface clientInterface;
    private transient StaffInterface staffInterface;
    private transient Feedback feedbackSystem;
    private transient Scanner scanner;

    // Available staff roles (using a Set to avoid duplicates and for efficient checking)
    private transient Set<String> availableStaffRoles = new HashSet<>();

    // Constructor
    public HotelManagementSystem() {
        rooms = new ArrayList<>();
        staffList = new ArrayList<>();
        scanner = new Scanner(System.in);
        initializeSystem();

        List<Role> availableStaffRoles = new ArrayList<>();
        staffInterface = new StaffInterface(staffList, availableStaffRoles);
        feedbackSystem = new Feedback();
        clientInterface = new ClientInterface(rooms,  feedbackSystem);
    }

    // System Initialization
    public void initializeSystem() {
        if (!loadSystemConfiguration()) {
            System.out.println("⚙️ First-time setup required.");
            initialSetup();
        } else {
            //If data is loaded, initialize availableStaffRoles
            initializeAvailableStaffRoles();
        }
    }

    // First-Time System Setup
    public void initialSetup() {
        System.out.println("🔒 Manager Setup");
        System.out.print("Enter Manager Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Manager Password: ");
        String password = scanner.nextLine();
        manager = new Manager(username, password);

        System.out.println("\n🏨 Hotel Configuration");
        System.out.print("Enter Number of Floors: ");
        int numFloors = getIntInput(scanner);

        List<Integer> roomsPerFloorList = new ArrayList<>();
        manager.initialSetup(roomsPerFloorList);
        initializeRooms(scanner, numFloors);

        // Initialize available staff roles.  Do this *after* initial staff are created.
        initializeAvailableStaffRoles();
        saveSystemConfiguration();
        System.out.println("✅ System setup completed successfully!\n");
    }

    // Initialize Rooms during First Setup
    private void initializeRooms(Scanner scanner, int numFloors) {
        int roomNumber = 101;
        for (int floor = 1; floor <= numFloors; floor++) {
            System.out.printf("\n--- Configuring Rooms for Floor %d ---\n", floor);
            System.out.print("Enter number of rooms for this floor: ");
            int roomsPerFloor = getIntInput(scanner);
            for (int i = 1; i <= roomsPerFloor; i++) {
                System.out.printf("\nConfiguring Room %d-%d:\n", floor, i);
                System.out.print("Enter Room Type (Standard/Deluxe/Suite): ");
                RoomType roomType = getValidRoomType(scanner);
                System.out.print("Enter Bed Type (Single/Double): ");
                String bedTypeInput = getValidBedType(scanner);
                BedType bedType = BedType.fromString(bedTypeInput);
                System.out.print("Enter Base Price Per Night: PKR ");
                double basePrice = getValidDoubleInput(scanner);
                double calculatedPrice;

                calculatedPrice = basePrice;

                rooms.add(new Room(String.valueOf(roomNumber++), roomType, bedType, calculatedPrice));
                System.out.printf("✅ Room %d-%d configured successfully!\n", floor, i);
            }
        }
    }



    private void initializeAvailableStaffRoles() {
        availableStaffRoles.clear(); // Clear first to handle data loading.

        for (Staff staff : staffList) {
            if (staff.getStatus().equalsIgnoreCase("Initial")) {
                String roleName = staff.getRole().toLowerCase();
                availableStaffRoles.add(roleName);
            }
        }

        // Add the main roles unconditionally.
        if (!availableStaffRoles.contains("front desk")) {
            availableStaffRoles.add("front desk");
        }
        if (!availableStaffRoles.contains("housekeeping")) {
            availableStaffRoles.add("housekeeping");
        }
        if (!availableStaffRoles.contains("maintenance")) {
            availableStaffRoles.add("maintenance");
        }
        if (!availableStaffRoles.contains("other")) {
            availableStaffRoles.add("other");
        }
    }



    // Helper method to validate integer input
    private int getIntInput(Scanner scanner) {
        while (true) {
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            } else {
                System.out.print("Invalid input. Please enter a valid number: ");
                scanner.next();
            }
        }
    }

    // Helper method to validate double input
    private double getValidDoubleInput(Scanner scanner) {
        while (true) {
            try {
                return Double.parseDouble(scanner.next());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a valid price: ");
            }
        }
    }

    // Helper method to validate room type input
    private RoomType getValidRoomType(Scanner scanner) {
        while (true) {
            String input = scanner.next().trim().toUpperCase();
            try {
                return RoomType.valueOf(input);
            } catch (IllegalArgumentException e) {
                System.out.print("Invalid room type. Enter (Standard/Deluxe/Suite): ");
            }
        }
    }

    // Helper method to validate bed type input
    private String getValidBedType(Scanner scanner) {
        while (true) {
            String input = scanner.next().trim().toLowerCase();
            if (input.equalsIgnoreCase("single") || input.equalsIgnoreCase("double")) {
                return input;
            } else {
                System.out.print("Invalid bed type. Enter (Single/Double): ");
            }
        }
    }

    private void displayAvailableStaffRoles() {
        if (availableStaffRoles.isEmpty()) {
            System.out.println("❌ No staff roles available.");
        } else {
            System.out.println("\nAvailable Staff Roles:");
            for (String role : availableStaffRoles) {
                System.out.println("👉 " + role);
            }
        }
    }

    private void addStaff() {
        String staffName;
        String role;
        String category = "Other";

        displayAvailableStaffRoles(); // Show available roles

        // Get staff name with validation
        while (true) {
            System.out.print("Enter Staff Name: ");
            staffName = scanner.nextLine().trim();
            if (staffName.isEmpty()) {
                System.out.println("Staff name cannot be empty. Please enter a valid name.");
            } else if (!staffName.matches("^[a-zA-Z\\s]+$")) {
                System.out.println("Staff name can only contain letters and spaces. Please enter a valid name.");
            } else {
                break;
            }
        }

        // Get staff role with validation, check if it is available
        while (true) {
            System.out.print("Enter Role: ");
            role = scanner.nextLine().trim();
            if (role.isEmpty()) {
                System.out.println("Role cannot be empty. Please enter a valid role.");
            } else if (!availableStaffRoles.contains(role)) {
                System.out.println("Role is not available or invalid.  Please choose from the available roles.");
            } else {
                break;
            }
        }

        // Determine staff category
        if (role.toLowerCase().contains("front desk")) {
            category = "Front Desk";
        } else if (role.toLowerCase().contains("housekeeping")) {
            category = "Housekeeping";
        } else if (role.toLowerCase().contains("maintenance")) {
            category = "Maintenance";
        } else {
            category = "Other";
        }

        Staff newStaff = new Staff(staffName, role, "New");
        staffList.add(newStaff);
        availableStaffRoles.remove(role); // Remove the assigned role
        System.out.println("New staff member added successfully. Category: " + category);
    }

    // Save system data (using file I/O)
    private void saveSystemConfiguration() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("system_data.dat"))) {
            out.writeObject(manager);
            out.writeObject(rooms);
            out.writeObject(staffList);
            out.writeObject(availableStaffRoles); //save available staff roles
            System.out.println("💾 Data saved successfully.");
        } catch (IOException e) {
            System.out.println("❗ Error saving system data: " + e.getMessage());
        }
    }

    // Load system data (using file I/O)
    @SuppressWarnings("unchecked")
    private boolean loadSystemConfiguration() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("system_data.dat"))) {
            manager = (Manager) in.readObject();
            rooms = (List<Room>) in.readObject();
            staffList = (List<Staff>) in.readObject();
            availableStaffRoles = (Set<String>) in.readObject();
            System.out.println("✅ System data loaded successfully.");
            return true;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❗ No saved data found. Proceeding with first-time setup.");
            rooms = new ArrayList<>(); // Initialize rooms here to ensure it's empty if no data is loaded
            return false;
        }
    }


    // Main Menu - Control System Flow
    public void displayMenu() {
        while (true) {
            System.out.println("\n🏨 Hotel Management System Menu:");
            System.out.println("1️⃣ - Client Interface");
            System.out.println("2️⃣ - Manager Interface (Password Protected)");
            System.out.println("3️⃣ - Exit");
            System.out.print("Choose an option: ");
            int choice = getIntInput(scanner);
            switch (choice) {
                case 1:
                    clientInterface.displayClientMenu();
                    break;
                case 2:
                    System.out.print("🔒 Enter Staff Password: ");
                    String password = scanner.next();
                    if (staffInterface.authenticateStaff(manager, password)) {
                        staffInterface.displayStaffMenu(manager);
                    } else {
                        System.out.println("❌ Incorrect password. Access denied.");
                    }
                    break;
                case 3:
                    System.out.println("👋 Exiting the system. Goodbye!");
                    saveSystemConfiguration();
                    scanner.close();
                    return;
                default:
                    System.out.println("❗ Invalid choice. Please try again.");
            }
        }
    }

    // Main Method to Start the System
    public static void main(String[] args) {
        HotelManagementSystem hotelSystem = new HotelManagementSystem();
        hotelSystem.displayMenu();
    }
}
