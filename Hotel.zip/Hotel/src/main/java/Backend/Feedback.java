package Backend;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Handles feedback collection, storage, and retrieval for hotel clients.
 */
public class Feedback implements Serializable {
    private static final long serialVersionUID = 1L; // Version control for serialization
    private static List<FeedbackRecord> feedbackRecords = new ArrayList<>();

    // Constructor for Feedback System (loads on instantiation)
    public Feedback() {
        loadFeedbackRecords();
    }

    /**
     * Static FeedbackRecord class for storing feedback details.
     */
    public static class FeedbackRecord implements Serializable {
        private static final long serialVersionUID = 1L; // Version control for serialization
        public String clientName;
        public String roomNumber;
        public int rating;
        public String comments;

        public FeedbackRecord(String clientName, String roomNumber, int rating, String comments) {
            this.clientName = clientName;
            this.roomNumber = roomNumber;
            this.rating = rating;
            this.comments = comments;
        }

        @Override
        public String toString() {
            return String.format("Client Name: %s, Room Number: %s, Rating: %d, FeedBack: %s",
                    clientName, roomNumber, rating, comments);
        }
    }

    /**
     * Collect feedback from a client and save it.
     */
    public void collectFeedback(String clientName, String roomNumber, String feedback, int rating) {
        // Create Feedback Record
        FeedbackRecord record = new FeedbackRecord(clientName, roomNumber, rating, feedback);
        feedbackRecords.add(record);
        saveFeedbackRecords();
        System.out.println("✅ Feedback submitted successfully! Thank you for your time.");
    }

    /**
     * Display all feedback records to the console.
     */
    public static void displayFeedbackRecords() {
        System.out.println("\n====== FEEDBACK RECORDS ======");
        for (FeedbackRecord record : feedbackRecords) {
            System.out.println(record);
        }
    }

    /**
     * Save feedback records to file (for data persistence).
     */
    private void saveFeedbackRecords() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("feedback_data.dat"))) {
            out.writeObject(feedbackRecords);
            System.out.println("💾 Feedback data saved successfully.");
        } catch (IOException e) {
            System.out.println("❗ Error saving feedback data: " + e.getMessage());
        }
    }

    /**
     * Load feedback records from file (on system start or as needed).
     */
    @SuppressWarnings("unchecked")
    private void loadFeedbackRecords() {
        File file = new File("feedback_data.dat");
        if (!file.exists()) {
            System.out.println("❗ No saved feedback data found. Starting with an empty list.");
            feedbackRecords = new ArrayList<>();
            return;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            feedbackRecords = (List<FeedbackRecord>) in.readObject();
            System.out.println("✅ Feedback data loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❗ Error loading feedback data: " + e.getMessage());
            feedbackRecords = new ArrayList<>();
        }
    }

    // ----------------- ADDITIONS FOR UI INTEGRATION & MANAGER PANEL -----------------

    /**
     * Static method to get all feedback records (for TableView in ManagerPanel).
     * @return List of all feedbacks
     */
    public static List<FeedbackRecord> loadFeedbackRecordsStatic() {
        File file = new File("feedback_data.dat");
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<FeedbackRecord>) in.readObject();
        } catch (Exception e) {
            System.out.println("❗ Error loading feedback data: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Static method to add a feedback record (can be used by UI).
     */
    public static void addFeedbackRecord(String clientName, String roomNumber, int rating, String comments) {
        List<FeedbackRecord> current = loadFeedbackRecordsStatic();
        FeedbackRecord record = new FeedbackRecord(clientName, roomNumber, rating, comments);
        current.add(record);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("feedback_data.dat"))) {
            out.writeObject(current);
            System.out.println("💾 Feedback data saved successfully (static add).");
        } catch (IOException e) {
            System.out.println("❗ Error saving feedback data: " + e.getMessage());
        }
    }

    /**
     * Static method to clear all feedback records (for testing/admin only).
     */
    public static void clearAllFeedback() {
        feedbackRecords = new ArrayList<>();
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("feedback_data.dat"))) {
            out.writeObject(feedbackRecords);
            System.out.println("🗑️ All feedback data cleared.");
        } catch (IOException e) {
            System.out.println("❗ Error clearing feedback data: " + e.getMessage());
        }
    }
}