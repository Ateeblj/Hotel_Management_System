package Backend;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TaskUtil {
    private static final String TASK_FILE = "task_data.dat";

    public static synchronized void saveTasks(List<Task> allTasks) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(TASK_FILE))) {
            out.writeObject(allTasks);
        } catch (IOException e) {
            System.out.println("❌ Error saving task data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static synchronized List<Task> loadTasks() {
        File file = new File(TASK_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            List<Task> tasks = (List<Task>) in.readObject();
            // Ensure all tasks have a valid id
            for (Task t : tasks) {
                t.ensureId();
            }
            saveTasks(tasks); // Save if any ID was missing
            return tasks;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❌ Error loading task data: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static synchronized void addTask(Task task) {
        List<Task> allTasks = loadTasks();
        allTasks.add(task);
        saveTasks(allTasks);
    }

    public static synchronized void updateTask(Task updatedTask) {
        List<Task> allTasks = loadTasks();
        boolean updated = false;
        for (int i = 0; i < allTasks.size(); i++) {
            Task t = allTasks.get(i);
            if (t.getId() != null && t.getId().equals(updatedTask.getId())) {
                allTasks.set(i, updatedTask);
                updated = true;
                break;
            }
        }
        if (updated) {
            saveTasks(allTasks);
        } else {
            System.out.println("❌ Task update failed: Could not find a matching task to update.");
        }
    }

    public static synchronized void deleteTask(Task taskToDelete) {
        List<Task> allTasks = loadTasks();
        boolean removed = allTasks.removeIf(t -> t.getId() != null && t.getId().equals(taskToDelete.getId()));
        if (removed) {
            saveTasks(allTasks);
        }
    }

    public static synchronized void unassignTasksOfStaff(String staffName) {
        List<Task> allTasks = loadTasks();
        boolean found = false;
        for (Task t : allTasks) {
            if (t.getAssignedTo().equalsIgnoreCase(staffName) && !t.getStatus().equalsIgnoreCase("Completed")) {
                t.setAssignedTo("Unassigned");
                t.setStatus("Pending");
                t.appendComment("Task unassigned on staff departure.");
                found = true;
            }
        }
        if (found) {
            saveTasks(allTasks);
            System.out.println("All incomplete tasks for " + staffName + " are now unassigned.");
        }
    }
}