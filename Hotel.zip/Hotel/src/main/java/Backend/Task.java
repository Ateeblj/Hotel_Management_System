package Backend;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Represents a task assigned to hotel staff.
 */
public class Task implements Serializable {
    private String id; // Unique identifier for robust update/delete
    private String description;
    private String assignedTo;
    private String status;     // "Pending", "In Progress", "Completed"
    private String priority;   // "Low", "Medium", "High"
    private LocalDate dueDate;
    private String comments;
    private String department;

    /**
     * Constructor for new Task (generates unique ID).
     */
    public Task(String description, String assignedTo, String priority, LocalDate dueDate, String department) {
        this.id = UUID.randomUUID().toString();
        this.description = description;
        this.assignedTo = assignedTo;
        this.priority = priority;
        this.dueDate = dueDate;
        this.status = "Pending";
        this.comments = "";
        this.department = department;
    }

    /**
     * Ensure a loaded task has an ID (for backward compatibility).
     */
    public void ensureId() {
        if (id == null || id.trim().isEmpty()) {
            id = UUID.randomUUID().toString();
        }
    }

    // ========== GETTERS AND SETTERS ==========

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getDescription() { return description; }
    public void setDescription(String newDescription) {
        if (newDescription == null || newDescription.trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty.");
        }
        this.description = newDescription.trim();
    }

    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    public void appendComment(String comment) {
        if (this.comments == null || this.comments.isEmpty()) {
            this.comments = comment;
        } else {
            this.comments += "\n" + comment;
        }
    }

    /**
     * Returns a formatted string for displaying the task.
     */
    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return "Task: " + description +
                "\nAssigned To: " + assignedTo +
                "\nDepartment: " + (department == null ? "N/A" : department) +
                "\nPriority: " + priority +
                "\nDue Date: " + (dueDate != null ? fmt.format(dueDate) : "N/A") +
                "\nStatus: " + status +
                (comments != null && !comments.isEmpty() ? ("\nComments:\n" + comments) : "");
    }
}