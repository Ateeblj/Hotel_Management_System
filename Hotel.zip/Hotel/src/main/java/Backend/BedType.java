package Backend;

public enum BedType {
    SINGLE,
    DOUBLE;

    @Override
    public String toString() {
        return name().substring(0, 1).toUpperCase() + name().substring(1).toLowerCase();
    }

    public static BedType fromString(String text) {
        if (text != null) {
            for (BedType b : BedType.values()) {
                if (b.toString().equalsIgnoreCase(text)) {
                    return b;
                }
            }
        }
        throw new IllegalArgumentException("No enum constant BedType." + text);
    }
}
