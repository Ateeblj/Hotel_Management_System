package Backend;

import java.io.Serializable;

public class Staff implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String name;
    private String role;
    private String status;
    private String contactInfo;

    // New fields for authentication
    private String username;
    private String password;

    public Staff(String id, String name, String role, String status, String contactInfo) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.status = status;
        this.contactInfo = contactInfo;
    }

    public Staff(String staffName, String role, String aNew) {
        name = staffName;
        this.role = role;
        status = aNew;
    }

    // New constructor with username and password
    public Staff(String id, String name, String role, String status, String contactInfo, String username, String password) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.status = status;
        this.contactInfo = contactInfo;
        this.username = username;
        this.password = password;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    // Username and password getters/setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Staff{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", status='" + status + '\'' +
                ", contactInfo='" + contactInfo + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}