package Backend;

import java.io.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Manager implements Serializable {
    private static final long serialVersionUID = 1L;

    private boolean isSetupComplete;
    private String staffPassword;
    private int totalFloors;
    private List<Integer> roomsPerFloorList;

    private String username;
    private String password;

    private static final String MANAGER_FILE = "manager_data.dat";

    // === Food Management Fields ===
    private static List<FoodItem> foodItems = new ArrayList<>();

    public Manager(String username, String password) {
        this.username = username;
        this.password = password;
        this.isSetupComplete = false;
    }

    // Initial Setup (One-Time)
    public void initialSetup(List<Integer> roomsPerFloorList) {
        if (isSetupComplete) {
            System.out.println("⚠️ Setup has already been completed. Reset the system to configure again.");
            return;
        }

        this.totalFloors = roomsPerFloorList.size();
        this.roomsPerFloorList = new ArrayList<>(roomsPerFloorList);

        Scanner sc = new Scanner(System.in);
        System.out.print("Set staff interface password: ");
        this.staffPassword = sc.nextLine();

        this.isSetupComplete = true;
        System.out.println("✅ Setup completed successfully!\n");
    }

    // Password Validation (For Staff Interface)
    public boolean validateStaffPassword(String inputPassword) {
        return inputPassword != null && inputPassword.equals(this.staffPassword);
    }
    public boolean validateManagerPassword(String inputPassword) {
        return inputPassword != null && inputPassword.equals(this.password);
    }
    public boolean validateManagerUsername(String inputUsername) {
        return inputUsername != null && inputUsername.equals(this.username);
    }

    // Reset System
    public boolean resetSystem(String managerPassword) {
        if (this.password.equals(managerPassword)) {
            this.isSetupComplete = false;
            this.staffPassword = null;
            this.totalFloors = 0;
            this.roomsPerFloorList = null;

            // Delete data files
            File systemDataFile = new File("system_data.dat");
            File clientDataFile = new File("client_data.dat");
            if (systemDataFile.exists() && !systemDataFile.delete()) {
                System.out.println("❌ Failed to delete system data file.");
            } else if (systemDataFile.exists()) {
                System.out.println("🔄 System data file deleted successfully.");
            }
            if (clientDataFile.exists() && !clientDataFile.delete()) {
                System.out.println("❌ Failed to delete client data file.");
            } else if (clientDataFile.exists()) {
                System.out.println("🔄 Client data file deleted successfully.");
            }

            this.foodItems.clear();

            System.out.println("🔄 System reset successfully. Please reconfigure.");
            return true;
        } else {
            System.out.println("❌ Incorrect manager password. System reset aborted.");
            return false;
        }
    }

    // Getters for floor and room details
    public int getTotalFloors() {
        return totalFloors;
    }

    public List<Integer> getRoomsPerFloorList() {
        return roomsPerFloorList == null ? new ArrayList<>() : new ArrayList<>(roomsPerFloorList);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean isSetupComplete() {
        return isSetupComplete;
    }

    public String getStaffPassword() {
        return staffPassword;
    }

    // ------------ Food Management Methods ------------

    // Get all food items
    public static List<FoodItem> getFoodItems() {
        return new ArrayList<>(foodItems);
    }

    // Add a new food item (prevent duplicates by name)
    public void addFoodItem(FoodItem item) {
        // Remove existing item with same name (case insensitive) if present
        foodItems.removeIf(f -> f.getName().equalsIgnoreCase(item.getName()));
        foodItems.add(item);
        saveManager(this);
    }

    // Update an existing food item by name (name as unique identifier)
    public boolean updateFoodItem(String oldName, FoodItem newItem) {
        for (int i = 0; i < foodItems.size(); i++) {
            FoodItem current = foodItems.get(i);
            if (current.getName().equalsIgnoreCase(oldName)) {
                foodItems.set(i, newItem);
                saveManager(this);
                return true;
            }
        }
        return false;
    }

    // Delete a food item by name
    public boolean deleteFoodItem(String name) {
        boolean removed = foodItems.removeIf(item -> item.getName().equalsIgnoreCase(name));
        if (removed) saveManager(this);
        return removed;
    }

    // ------------ Persistence Methods ------------

    // Save the manager object to file
    public static void saveManager(Manager manager) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(MANAGER_FILE))) {
            out.writeObject(manager);
        } catch (Exception e) {
            System.out.println("❗ Error saving manager info: " + e.getMessage());
        }
    }

    // Load the manager object from file
    public static Manager loadManager() {
        File file = new File(MANAGER_FILE);
        if (!file.exists()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (Manager) in.readObject();
        } catch (Exception e) {
            System.out.println("❗ Error loading manager info: " + e.getMessage());
            return null;
        }
    }
}