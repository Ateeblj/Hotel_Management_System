package Backend;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Represents a client who books a room in the hotel.
 * Stores personal details, booking details, and payment information.
 */
public class Client implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String cnic;
    private String address;
    private String phoneNumber;
    private String email;
    private double amount; // Total amount paid for the booking
    private String bookedRoomNumber;
    private LocalDate bookingEndDate;
    private int nights; // Number of nights booked

    /**
     * Constructs a Client object with provided booking and personal details.
     *
     * @param name             Client's name
     * @param cnic             Client's CNIC/ID
     * @param phoneNumber      Client's phone number
     * @param email            Client's email
     * @param bookedRoomNumber Room number booked by the client
     * @param address          Client's address
     * @param nights           Number of nights booked
     * @param amount           Amount paid
     */
    public Client(String name, String cnic, String phoneNumber, String email, String bookedRoomNumber, String address, int nights, double amount) {
        this.name = name;
        this.cnic = cnic;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.amount = amount;
        this.bookedRoomNumber = bookedRoomNumber;
        this.bookingEndDate = null;
        this.nights = nights;
    }

    // Getters

    public String getName() {
        return name;
    }

    public double getAmount() {
        return amount;
    }

    public String getCnic() {
        return cnic;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getBookedRoomNumber() {
        return bookedRoomNumber;
    }

    public LocalDate getBookingEndDate() {
        return bookingEndDate;
    }

    public int getNights() {
        return nights;
    }

    // Setters

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setBookingEndDate(LocalDate bookingEndDate) {
        this.bookingEndDate = bookingEndDate;
    }

    public void setNights(int nights) {
        this.nights = nights;
    }

    /**
     * Books a room for the client by assigning room number and booking end date.
     *
     * @param roomNumber Room number to book
     * @param endDate    End date of the booking
     */
    public void bookRoom(String roomNumber, LocalDate endDate) {
        this.bookedRoomNumber = roomNumber;
        this.bookingEndDate = endDate;
    }

    /**
     * Cancels the client's booking by resetting room and date info.
     */
    public void cancelBooking() {
        this.bookedRoomNumber = null;
        this.bookingEndDate = null;
    }

    @Override
    public String toString() {
        return "Client{" +
                "name='" + name + '\'' +
                ", cnic='" + cnic + '\'' +
                ", address='" + address + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", amount=" + amount +
                ", bookedRoomNumber='" + bookedRoomNumber + '\'' +
                ", bookingEndDate=" + bookingEndDate +
                ", nights=" + nights +
                '}';
    }

    /**
     * Returns the total cost paid by the client for the booking.
     * This is used for refunding upon cancellation.
     * @return the amount paid for the booking
     */
    public double getTotalCost() {
        return amount;
    }


}