package Backend;

import java.time.LocalDateTime;

public class FeeSlip {
    private String clientName;
    private String roomNumber;
    private double amountPaid;
    private LocalDateTime paymentDate;
    private String paymentMethod;

    public FeeSlip(String clientName, String roomNumber, double amountPaid, LocalDateTime paymentDate, String paymentMethod) {
        this.clientName = clientName;
        this.roomNumber = roomNumber;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
    }

    public String getClientName() { return clientName; }
    public String getRoomNumber() { return roomNumber; }
    public double getAmountPaid() { return amountPaid; }
    public LocalDateTime getPaymentDate() { return paymentDate; }
    public String getPaymentMethod() { return paymentMethod; }
}