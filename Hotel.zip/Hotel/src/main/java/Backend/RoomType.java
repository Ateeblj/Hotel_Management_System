package Backend;

public enum RoomType {
    STANDARD,
    DELUXE,
    SUITE
}
