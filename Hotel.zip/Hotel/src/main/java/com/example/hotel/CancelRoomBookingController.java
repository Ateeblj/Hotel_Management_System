package com.example.hotel;

import Backend.Room;
import Backend.Client;
import Backend.ClientFileUtil;
import Backend.RoomManager;
import Backend.FeeSlip;
import Backend.FeeSlipUtil;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class CancelRoomBookingController {
    @FXML private TextField tfClientName;
    @FXML private TextField tfRoomNumber;
    @FXML private Button btnCancel;
    @FXML private Button btnBack;
    @FXML private Label lblStatus;
    @FXML private Label lblRefundAmount;

    @FXML
    public void initialize() {
        lblStatus.setText("");
        lblRefundAmount.setText("");
        btnCancel.setOnAction(e -> handleCancel());
        btnBack.setOnAction(e -> handleBack());
    }

    private void handleCancel() {
        String name = tfClientName.getText().trim();
        String roomNumber = tfRoomNumber.getText().trim();

        lblStatus.setText("");
        lblRefundAmount.setText("");

        if (name.isEmpty() || roomNumber.isEmpty()) {
            lblStatus.setText("Please enter your name and room number.");
            lblStatus.setTextFill(javafx.scene.paint.Color.RED);
            return;
        }

        // Find the occupied room
        List<Room> rooms = RoomManager.loadRoomsFromFile();
        Room bookedRoom = null;
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber) && room.isOccupied()) {
                bookedRoom = room;
                break;
            }
        }
        if (bookedRoom == null) {
            lblStatus.setText("No such occupied room found.");
            lblStatus.setTextFill(javafx.scene.paint.Color.RED);
            return;
        }

        // Find client with this name and room number
        Client client = null;
        List<Client> clients = ClientFileUtil.loadClients();
        for (Client c : clients) {
            if (c.getName().equalsIgnoreCase(name) && roomNumber.equals(c.getBookedRoomNumber())) {
                client = c;
                break;
            }
        }
        if (client == null) {
            lblStatus.setText("No client booking found under your name for this room.");
            lblStatus.setTextFill(javafx.scene.paint.Color.RED);
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDate endDate = bookedRoom.getBookingEndDate();
        long nightsLeft = (endDate != null) ? endDate.toEpochDay() - today.toEpochDay() : 0;
        if (nightsLeft < 0) nightsLeft = 0;
        double refund = nightsLeft * bookedRoom.getPricePerNight();

        // Update room status
        bookedRoom.checkoutRoom();
        RoomManager.saveRoomsToFile(rooms);

        // Update client info
        client.cancelBooking();
        client.setAmount(client.getAmount() + refund); // Optionally, keep as is or for logging
        ClientFileUtil.saveClients(clients);

        // Generate cancellation slip
        FeeSlipUtil.saveFeeSlip(
                new FeeSlip(
                        client.getName(),
                        bookedRoom.getRoomNumber(),
                        -refund,
                        java.time.LocalDateTime.now(),
                        "Refund"
                )
        );

        lblRefundAmount.setText(String.format("Refund: PKR %.2f", refund));
        lblStatus.setText("Booking cancelled.");
        lblStatus.setTextFill(javafx.scene.paint.Color.GREEN);
    }

    private void handleBack() {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}