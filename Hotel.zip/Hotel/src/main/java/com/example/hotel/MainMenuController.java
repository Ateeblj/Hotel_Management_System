package com.example.hotel;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class MainMenuController {
    @FXML
    private void openClientInterface(ActionEvent event) {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openStaffInterface(ActionEvent event) {
        try {
            Main.loadScene("StaffMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void exitApp(ActionEvent event) {
        System.exit(0);
    }
}