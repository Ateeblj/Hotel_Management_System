package com.example.hotel;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ClientMenuController {
    @FXML
    private void viewRooms(ActionEvent event) {
        try {
            Main.loadScene("ViewRooms.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void orderFood(ActionEvent event) {
        try {
            Main.loadScene("FoodOrder.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ... similarly for other buttons
    // ... similarly for other buttons
    @FXML
    private void bookRoom(ActionEvent event) {
        try {
            Main.loadScene("BookRoom.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void submitFeedback(ActionEvent event) {
        try {
            Main.loadScene("Feedback.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void cancelBooking(ActionEvent event) {
        try {
            Main.loadScene("CancelBooking.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void backToMain(ActionEvent event) {
        try {
            Main.loadScene("MainMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}