package com.example.hotel;

import Backend.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HotelSetupController {

    // Panes
    @FXML private StackPane rootPane;
    @FXML private VBox managerStep, floorStep, roomsPerFloorStep, roomDetailsStep, summaryStep;

    // Manager fields
    @FXML private TextField tfUsername;
    @FXML private PasswordField pfPassword;

    // Floor fields
    @FXML private TextField tfNumFloors;

    // Rooms per floor fields
    @FXML private Label lblFloor;
    @FXML private TextField tfRoomsThisFloor;

    // Room details fields
    @FXML private Label lblRoom;
    @FXML private ComboBox<String> cbRoomType;
    @FXML private ComboBox<String> cbBedType;
    @FXML private TextField tfBasePrice;

    // Summary
    @FXML private TextArea taSummary;

    // Backend data
    private String managerUsername;
    private String managerPassword;
    private int numFloors;
    private List<Integer> roomsPerFloorList = new ArrayList<>();
    private List<List<Room>> allRooms = new ArrayList<>();
    private int currentFloor = 1;
    private int currentRoom = 1;
    private int currentRoomsForFloor = 0;
    private int roomsEnteredThisFloor = 0;

    private static final String CREDENTIALS_FILE = "credentials.dat";

    @FXML
    private void initialize() {
        cbRoomType.setItems(FXCollections.observableArrayList("Standard", "Deluxe", "Suite"));
        cbBedType.setItems(FXCollections.observableArrayList("Single", "Double"));
        // Only managerStep is visible at first, hide others
        managerStep.setVisible(true);
        floorStep.setVisible(false);
        roomsPerFloorStep.setVisible(false);
        roomDetailsStep.setVisible(false);
        summaryStep.setVisible(false);
    }

    @FXML
    private void onManagerNext() {
        if (tfUsername.getText().trim().isEmpty() || pfPassword.getText().trim().isEmpty()) {
            showAlert("Both manager username and password are required.");
            return;
        }
        managerUsername = tfUsername.getText().trim();
        managerPassword = pfPassword.getText().trim();
        // Skip staff password step and go directly to floor setup
        floorStep.setVisible(true);
        managerStep.setVisible(false);
    }

    @FXML
    private void onFloorNext() {
        try {
            int floors = Integer.parseInt(tfNumFloors.getText().trim());
            if (floors <= 0) throw new NumberFormatException();
            numFloors = floors;
            currentFloor = 1;
            lblFloor.setText("--- Configuring Rooms for Floor " + currentFloor + " ---");
            floorStep.setVisible(false);
            roomsPerFloorStep.setVisible(true);
        } catch (NumberFormatException ex) {
            showAlert("Please enter a valid positive number of floors.");
        }
    }

    @FXML
    private void onRoomsPerFloorNext() {
        try {
            int rooms = Integer.parseInt(tfRoomsThisFloor.getText().trim());
            if (rooms <= 0) throw new NumberFormatException();
            roomsPerFloorList.add(rooms);
            currentRoomsForFloor = rooms;
            roomsEnteredThisFloor = 0;
            currentRoom = 1;
            allRooms.add(new ArrayList<>());
            lblRoom.setText(String.format("Configuring Room %d-%d", currentFloor, currentRoom));
            cbRoomType.setValue(null);
            cbBedType.setValue(null);
            tfBasePrice.setText("");
            roomsPerFloorStep.setVisible(false);
            roomDetailsStep.setVisible(true);
        } catch (NumberFormatException ex) {
            showAlert("Please enter a valid positive number of rooms.");
        }
    }

    @FXML
    private void onRoomDetailsNext() {
        String roomType = cbRoomType.getValue();
        String bedType = cbBedType.getValue();
        String priceText = tfBasePrice.getText().trim();
        if (roomType == null || bedType == null || priceText.isEmpty()) {
            showAlert("Please fill out all fields for the room.");
            return;
        }
        try {
            double price = Double.parseDouble(priceText);
            if (price < 0) throw new NumberFormatException();
            RoomType selectedRoomType = RoomType.valueOf(roomType.toUpperCase());
            BedType selectedBedType = BedType.fromString(bedType);
            String roomNumber = String.valueOf(100 * currentFloor + currentRoom);
            Room newRoom = new Room(roomNumber, selectedRoomType, selectedBedType, price);
            allRooms.get(currentFloor - 1).add(newRoom);

            roomsEnteredThisFloor++;
            currentRoom++;
            if (roomsEnteredThisFloor < currentRoomsForFloor) {
                lblRoom.setText(String.format("Configuring Room %d-%d", currentFloor, currentRoom));
                cbRoomType.setValue(null);
                cbBedType.setValue(null);
                tfBasePrice.setText("");
            } else {
                currentFloor++;
                if (currentFloor <= numFloors) {
                    lblFloor.setText("--- Configuring Rooms for Floor " + currentFloor + " ---");
                    tfRoomsThisFloor.setText("");
                    roomDetailsStep.setVisible(false);
                    roomsPerFloorStep.setVisible(true);
                } else {
                    showSummary();
                }
            }
        } catch (Exception ex) {
            showAlert("Please enter a valid non-negative price.");
        }
    }

    @FXML
    private void onFinish() {
        // Flatten allRooms (List<List<Room>>) to a single List<Room>
        List<Room> flatRoomList = new ArrayList<>();
        for (List<Room> floorRooms : allRooms) {
            flatRoomList.addAll(floorRooms);
        }
        // Save the list using ObjectOutputStream
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("rooms.dat"))) {
            oos.writeObject(flatRoomList);
        } catch (IOException e) {
            showAlert("Failed to save room data: " + e.getMessage());
            return;
        }
        // Save credentials (no staff password now)
        try (PrintWriter out = new PrintWriter(new FileWriter(CREDENTIALS_FILE))) {
            out.println("managerName=" + managerUsername);
            out.println("managerPassword=" + managerPassword);
        } catch (IOException e) {
            showAlert("Failed to save credentials: " + e.getMessage());
            return;
        }
        // Now flow into the main menu of the system
        try {
            Main.loadScene("MainMenu.fxml");
        } catch (Exception e) {
            showAlert("Failed to load main menu.");
        }
    }

    private void showSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Manager: ").append(managerUsername).append("\nFloors: ").append(numFloors).append("\n");
        for (int f = 0; f < numFloors; f++) {
            sb.append("Floor ").append(f + 1).append(": ").append(roomsPerFloorList.get(f)).append(" rooms\n");
            for (Room r : allRooms.get(f)) {
                sb.append("   Room ").append(r.getRoomNumber()).append(": ")
                        .append(r.getRoomType()).append(", ")
                        .append(r.getBedType()).append(", PKR ")
                        .append(r.getBasePrice()).append("\n");
            }
        }
        taSummary.setText(sb.toString());
        roomDetailsStep.setVisible(false);
        summaryStep.setVisible(true);
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.showAndWait();
    }
}