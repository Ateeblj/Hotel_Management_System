package com.example.hotel;

import Backend.Staff;
import Backend.StaffManager;
import Backend.Task;
import Backend.TaskUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StaffTaskPanelController {

    @FXML private TableView<Task> tableTasks;
    @FXML private TableColumn<Task, String> colDesc;
    @FXML private TableColumn<Task, String> colPriority;
    @FXML private TableColumn<Task, String> colDueDate;
    @FXML private TableColumn<Task, String> colStatus;
    @FXML private TableColumn<Task, String> colComments;
    @FXML private Button btnUpdateStatus;
    @FXML private Button btnAddComment;
    @FXML private Button btnRefresh;
    @FXML private Button btnBack;

    private ObservableList<Task> myTasks = FXCollections.observableArrayList();

    private Staff loggedInStaff = null;

    @FXML
    private void initialize() {
        boolean authenticated = showStaffLoginDialog();
        if (!authenticated) {
            tableTasks.sceneProperty().addListener((obs, oldScene, newScene) -> {
                if (newScene != null) {
                    Stage stage = (Stage) tableTasks.getScene().getWindow();
                    stage.close();
                }
            });
            return;
        }

        colDesc.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDescription()));
        colPriority.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getPriority()));
        colDueDate.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().getDueDate() != null ? cellData.getValue().getDueDate().toString() : "N/A"));
        colStatus.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        colComments.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getComments()));

        btnRefresh.setOnAction(e -> refreshTasks());
        btnUpdateStatus.setOnAction(e -> handleUpdateStatus());
        btnAddComment.setOnAction(e -> handleAddComment());
        btnBack.setOnAction(e -> handleBack());

        refreshTasks();
    }

    private boolean showStaffLoginDialog() {
        Dialog<Staff> dialog = new Dialog<>();
        dialog.setTitle("Staff Login");

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");

        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.add(userLabel, 0, 0);
        grid.add(userField, 1, 0);
        grid.add(passLabel, 0, 1);
        grid.add(passField, 1, 1);
        grid.add(errorLabel, 0, 2, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            String username = userField.getText().trim();
            String password = passField.getText();
            if (username.isEmpty() || password.isEmpty()) {
                errorLabel.setText("Please enter both username and password.");
                event.consume();
            } else {
                Staff staff = StaffManager.findStaffByUsernameAndPassword(username, password);
                if (staff == null || !"Active".equalsIgnoreCase(staff.getStatus())) {
                    errorLabel.setText("Incorrect username/password or staff is not active.");
                    event.consume();
                } else {
                    errorLabel.setText("");
                    dialog.setResult(staff);
                }
            }
        });

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String username = userField.getText().trim();
                String password = passField.getText();
                Staff staff = StaffManager.findStaffByUsernameAndPassword(username, password);
                if (staff != null && "Active".equalsIgnoreCase(staff.getStatus())) {
                    return staff;
                }
            }
            return null;
        });

        Optional<Staff> result = dialog.showAndWait();
        if (result.isPresent()) {
            loggedInStaff = result.get();
            return true;
        }
        return false;
    }

    private void refreshTasks() {
        if (loggedInStaff == null) {
            tableTasks.setItems(FXCollections.observableArrayList());
            return;
        }
        List<Task> allTasks = TaskUtil.loadTasks();
        List<Task> assigned = allTasks.stream()
                .filter(t -> t.getAssignedTo() != null
                        && t.getAssignedTo().equalsIgnoreCase(loggedInStaff.getName())
                        && !"Completed".equalsIgnoreCase(t.getStatus()))
                .collect(Collectors.toList());
        myTasks.setAll(assigned);
        tableTasks.setItems(myTasks);
    }

    private void handleUpdateStatus() {
        Task selected = tableTasks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a task to update.");
            return;
        }
        ChoiceDialog<String> dialog = new ChoiceDialog<>(selected.getStatus(), "Pending", "In Progress", "Completed");
        dialog.setTitle("Update Task Status");
        dialog.setHeaderText("Update status for: " + selected.getDescription());
        dialog.setContentText("Select new status:");
        dialog.showAndWait().ifPresent(newStatus -> {
            selected.setStatus(newStatus);
            TaskUtil.updateTask(selected);
            refreshTasks();
            showAlert("Status updated.");
        });
    }

    private void handleAddComment() {
        Task selected = tableTasks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a task to add/view comments.");
            return;
        }
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add Comment");
        dialog.setHeaderText("Add a comment for: " + selected.getDescription());
        dialog.setContentText("Enter comment:");
        dialog.showAndWait().ifPresent(comment -> {
            if (comment.trim().isEmpty()) return;
            selected.appendComment("[" + loggedInStaff.getName() + " @ " + java.time.LocalDate.now() + "]: " + comment);
            TaskUtil.updateTask(selected);
            refreshTasks();
            showAlert("Comment added.");
        });
    }

    private void handleBack() {
        try {
            Main.loadScene("StaffMenu.fxml");
        } catch (Exception e) {
            showAlert("Failed to go back: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.showAndWait();
    }
}