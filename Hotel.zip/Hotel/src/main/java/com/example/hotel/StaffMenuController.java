package com.example.hotel;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class StaffMenuController {


    @FXML private Button btnTaskPanel;
    @FXML private Button btnManagerPanel;
    @FXML private Button btnBack;

    @FXML
    private void initialize() {

        btnTaskPanel.setOnAction(e -> {
            try {
                Main.loadScene("StaffTaskPanel.fxml");
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        btnManagerPanel.setOnAction(e -> {
            try {
                Main.loadScene("ManagerPanel.fxml");
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        btnBack.setOnAction(e -> handleBack());
    }

    private void handleBack() {
        try {
            Main.loadScene("MainMenu.fxml"); // Or wherever you want to return (maybe a Login or RoleSelect screen)
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}