package com.example.hotel;

import Backend.Staff;
import Backend.StaffManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.util.UUID;

public class AddStaffController {

    @FXML private TextField tfid;
    @FXML private TextField tfName;
    @FXML private TextField tfRole;
    @FXML private TextField tfContact;
    @FXML private ComboBox<String> cbStatus;
    @FXML private TextField tfUsername;
    @FXML private PasswordField pfPassword;
    @FXML private Button btnAdd;
    @FXML private Button btnBack;

    private Staff createdStaff;

    @FXML
    private void initialize() {
        cbStatus.getItems().addAll("Active", "On Leave", "Left");
        cbStatus.setValue("Active");

        btnAdd.setOnAction(this::handleAddStaff);
        btnBack.setOnAction(this::handleBack);
    }

    private void handleAddStaff(ActionEvent event) {

        String id = tfid.getText().trim();
        String name = tfName.getText().trim();
        String role = tfRole.getText().trim();
        String contact = tfContact.getText().trim();
        String status = cbStatus.getValue();
        String username = tfUsername.getText().trim();
        String password = pfPassword.getText().trim();

        if (name.isEmpty() || role.isEmpty() || contact.isEmpty() ||
                status == null || status.isEmpty() || username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Please fill in all fields.");
            return;
        }

        if (!name.matches("^[a-zA-Z\\s]+$")) {
            showAlert(Alert.AlertType.ERROR, "Name can only contain letters and spaces.");
            return;
        }


        Staff staff = new Staff(id, name, role, status, contact, username, password);
        StaffManager.addStaff(staff);

        showAlert(Alert.AlertType.INFORMATION,
                "Staff member added successfully!\n\nUsername: " + username + "\nPassword: " + password);

        createdStaff = staff; // Store for caller if needed

        clearFields();

        // Close window if you want to auto-close after adding
        Stage stage = (Stage) btnAdd.getScene().getWindow();
        if (stage != null) {
            stage.close();
        }
    }

    private void clearFields() {
        tfName.clear();
        tfRole.clear();
        tfContact.clear();
        cbStatus.setValue("Active");
        tfUsername.clear();
        pfPassword.clear();
    }

    private void handleBack(ActionEvent event) {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        if (stage != null) {
            stage.close();
        }
        // If you want to go back to main menu scene:
        // try { Main.loadScene("StaffMenu.fxml"); } catch (Exception e) { showAlert(...); }
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.showAndWait();
    }

    // Optional: For parent controller to fetch created staff after dialog closes
    public Staff getCreatedStaff() {
        return createdStaff;
    }

    public TextField getTfid() {
        return tfid;
    }

    public void setTfid(TextField tfid) {
        this.tfid = tfid;
    }
}