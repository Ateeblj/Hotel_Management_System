package com.example.hotel;

import Backend.FoodItem;
import Backend.Manager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class FoodManagementController {
    @FXML private TableView<FoodItem> tableFood;
    @FXML private TableColumn<FoodItem, String> colName;
    @FXML private TableColumn<FoodItem, Double> colPrice;
    @FXML private TableColumn<FoodItem, Integer> colQuantity;
    @FXML private TextField txtName;
    @FXML private TextField txtPrice;
    @FXML private TextField txtQuantity;
    @FXML private Button btnAdd;
    @FXML private Button btnUpdate;
    @FXML private Button btnDelete;

    private ObservableList<FoodItem> foodData = FXCollections.observableArrayList();

    private Manager manager;

    @FXML
    private void initialize() {
        manager = Manager.loadManager();
        if (manager == null) {
            showAlert("Manager data not found! Please set up the manager first.", Alert.AlertType.ERROR);
            disableAll();
            return;
        }

        colName.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getName()));
        colPrice.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<Double>(cell.getValue().getPrice()));
        colQuantity.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<Integer>(cell.getValue().getQuantity()));
        loadFoodTable();

        btnAdd.setOnAction(e -> handleAdd());
        btnUpdate.setOnAction(e -> handleUpdate());
        btnDelete.setOnAction(e -> handleDelete());

        tableFood.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtName.setText(newSel.getName());
                txtPrice.setText(String.valueOf(newSel.getPrice()));
                txtQuantity.setText(String.valueOf(newSel.getQuantity()));
            }
        });
    }

    private void loadFoodTable() {
        List<FoodItem> items = manager.getFoodItems();
        foodData.setAll(items);
        tableFood.setItems(foodData);
    }

    private void handleAdd() {
        String name = txtName.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String quantityStr = txtQuantity.getText().trim();
        if (name.isEmpty() || priceStr.isEmpty() || quantityStr.isEmpty()) {
            showAlert("All fields are required.", Alert.AlertType.INFORMATION);
            return;
        }
        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            showAlert("Invalid number format.", Alert.AlertType.INFORMATION);
            return;
        }
        FoodItem item = new FoodItem(name, price, quantity);
        manager.addFoodItem(item);
        Manager.saveManager(manager);
        loadFoodTable();
        clearFields();
    }

    private void handleUpdate() {
        FoodItem selected = tableFood.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select an item to update.", Alert.AlertType.INFORMATION);
            return;
        }
        String name = txtName.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String quantityStr = txtQuantity.getText().trim();
        if (name.isEmpty() || priceStr.isEmpty() || quantityStr.isEmpty()) {
            showAlert("All fields are required.", Alert.AlertType.INFORMATION);
            return;
        }
        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            showAlert("Invalid number format.", Alert.AlertType.INFORMATION);
            return;
        }
        FoodItem updated = new FoodItem(name, price, quantity);
        boolean success = manager.updateFoodItem(selected.getName(), updated);
        if (success) {
            Manager.saveManager(manager);
            loadFoodTable();
            clearFields();
        } else {
            showAlert("Update failed. Item not found.", Alert.AlertType.ERROR);
        }
    }

    private void handleDelete() {
        FoodItem selected = tableFood.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select an item to delete.", Alert.AlertType.INFORMATION);
            return;
        }
        boolean success = manager.deleteFoodItem(selected.getName());
        if (success) {
            Manager.saveManager(manager);
            loadFoodTable();
            clearFields();
        } else {
            showAlert("Delete failed. Item not found.", Alert.AlertType.ERROR);
        }
    }

    private void clearFields() {
        txtName.clear();
        txtPrice.clear();
        txtQuantity.clear();
    }

    private void disableAll() {
        if (tableFood != null) tableFood.setDisable(true);
        if (txtName != null) txtName.setDisable(true);
        if (txtPrice != null) txtPrice.setDisable(true);
        if (txtQuantity != null) txtQuantity.setDisable(true);
        if (btnAdd != null) btnAdd.setDisable(true);
        if (btnUpdate != null) btnUpdate.setDisable(true);
        if (btnDelete != null) btnDelete.setDisable(true);
    }

    private void showAlert(String msg, Alert.AlertType type) {
        Alert alert = new Alert(type, msg, ButtonType.OK);
        alert.showAndWait();
    }
}