package com.example.hotel;

import Backend.FoodItem;
import Backend.Room;
import Backend.RoomManager;
import Backend.Task;
import Backend.TaskUtil;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class FoodOrderController {
    @FXML private TextField tfClientName;
    @FXML private TextField tfRoomNumber;
    @FXML private ListView<FoodItem> lvMenu;
    @FXML private ListView<FoodItem> lvSelected;
    @FXML private Label lblTotal;
    @FXML private Button btnBuy;
    @FXML private Button btnBack;
    @FXML private TextArea taOrderSummary;
    @FXML private TextField tfAmountPaid;

    private List<FoodItem> selectedItems = new ArrayList<>();
    private Map<FoodItem, Integer> selectedQuantities = new HashMap<>();
    private List<Room> allRooms = new ArrayList<>();

    @FXML
    private void initialize() {
        allRooms = RoomManager.loadRoomsFromFile();
        refreshMenu();
        lvMenu.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        lvMenu.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> updateSelectedItems());
        btnBuy.setOnAction(e -> buyFood());
        btnBack.setOnAction(e -> goBack());
        updateTotal();
    }

    private void refreshMenu() {
        List<FoodItem> menuItems = FoodItem.loadFoodItems();
        if (menuItems.isEmpty()) {
            showAlert("Food menu not found! Please contact the manager to set up food items.");
            btnBuy.setDisable(true);
            lvMenu.setItems(FXCollections.observableArrayList());
            return;
        }
        btnBuy.setDisable(false);
        lvMenu.setItems(FXCollections.observableArrayList(menuItems));
    }

    private void updateSelectedItems() {
        selectedItems.clear();
        selectedQuantities.clear();

        List<FoodItem> selectedFromList = lvMenu.getSelectionModel().getSelectedItems();
        for (FoodItem food : selectedFromList) {
            int maxQty = food.getQuantity();
            TextInputDialog dialog = new TextInputDialog("1");
            dialog.setTitle("Quantity for " + food.getName());
            dialog.setHeaderText("Enter quantity for " + food.getName() + " (Available: " + maxQty + ")");
            dialog.setContentText("Quantity:");
            int qty = 0;
            while (qty <= 0 || qty > maxQty) {
                Optional<String> result = dialog.showAndWait();
                if (result.isEmpty()) return;
                try {
                    qty = Integer.parseInt(result.get().trim());
                    if (qty <= 0) showAlert("Quantity must be greater than zero.");
                    else if (qty > maxQty) showAlert("Cannot order more than available (" + maxQty + ").");
                } catch (NumberFormatException e) {
                    showAlert("Please enter a valid quantity.");
                }
            }
            selectedItems.add(food);
            selectedQuantities.put(food, qty);
        }
        lvSelected.setItems(FXCollections.observableArrayList(selectedItems));
        updateTotal();
    }

    private void updateTotal() {
        double total = 0;
        for (FoodItem item : selectedItems) {
            int qty = selectedQuantities.getOrDefault(item, 1);
            total += item.getPrice() * qty;
        }
        lblTotal.setText("Total: $" + String.format("%.2f", total));
    }

    private Room getBookedRoom(String roomNumber) {
        for (Room r : allRooms) {
            if (r.getRoomNumber().equals(roomNumber)) {
                r.updateAvailability();
                if (r.isOccupied()) {
                    return r;
                }
                break;
            }
        }
        return null;
    }

    private void buyFood() {
        String clientName = tfClientName.getText().trim();
        String roomNumber = tfRoomNumber.getText().trim();
        String amountText = tfAmountPaid.getText().trim();

        if (clientName.isEmpty() || roomNumber.isEmpty()) {
            showAlert("Please enter client name and room number.");
            return;
        }
        if (selectedItems.isEmpty()) {
            showAlert("Please select at least one food item.");
            return;
        }
        if (amountText.isEmpty()) {
            showAlert("Please enter the amount paid.");
            return;
        }

        // Check quantities against current menu to avoid ordering more than available
        Map<String, Integer> availableMap = new HashMap<>();
        for (FoodItem food : FoodItem.loadFoodItems()) {
            availableMap.put(food.getName(), food.getQuantity());
        }
        for (FoodItem item : selectedItems) {
            int orderedQty = selectedQuantities.getOrDefault(item, 1);
            int availableQty = availableMap.getOrDefault(item.getName(), 0);
            if (orderedQty > availableQty) {
                showAlert("Ordered quantity for " + item.getName() + " exceeds available (" + availableQty + ").");
                return;
            }
        }

        double total = 0;
        for (FoodItem item : selectedItems) {
            int qty = selectedQuantities.getOrDefault(item, 1);
            total += item.getPrice() * qty;
        }

        double amountPaid;
        try {
            amountPaid = Double.parseDouble(amountText);
        } catch (NumberFormatException e) {
            showAlert("Please enter a valid number for the amount paid.");
            return;
        }

        if (amountPaid < total) {
            showAlert("Money is not enough. Please provide at least $" + String.format("%.2f", total));
            return;
        }

        Room matchedRoom = getBookedRoom(roomNumber);
        if (matchedRoom == null) {
            showAlert("Room number not found or the room is not booked. Only guests with a valid, booked room can order food.");
            return;
        }

        double change = amountPaid - total;

        StringBuilder sb = new StringBuilder();
        sb.append("Order Time: ").append(LocalDateTime.now()).append('\n');
        sb.append("Client Name: ").append(clientName).append('\n');
        sb.append("Room Number: ").append(roomNumber).append('\n');
        sb.append("Items:\n");
        for (FoodItem item : selectedItems) {
            int qty = selectedQuantities.getOrDefault(item, 1);
            sb.append(" - ").append(item.getName())
                    .append(" x").append(qty)
                    .append(" ($").append(String.format("%.2f", item.getPrice()))
                    .append(" each, Subtotal $").append(String.format("%.2f", item.getPrice() * qty)).append(")\n");
        }
        sb.append("Total: $").append(String.format("%.2f", total)).append("\n");
        sb.append("Amount Paid: $").append(String.format("%.2f", amountPaid)).append("\n");
        if (change > 0.0) {
            sb.append("Change: $").append(String.format("%.2f", change)).append("\n");
        }
        sb.append("-------------------------------------------------------\n");

        // Save order immediately
        try (FileWriter fw = new FileWriter("food_orders.txt", true)) {
            fw.write(sb.toString());
        } catch (IOException e) {
            showAlert("Failed to save order: " + e.getMessage());
            return;
        }

        // ----------- ADD THIS: Create a Task for the Manager Panel -----------
        StringBuilder taskDesc = new StringBuilder("Food order for Room ");
        taskDesc.append(roomNumber).append(": ");
        for (FoodItem item : selectedItems) {
            int qty = selectedQuantities.getOrDefault(item, 1);
            taskDesc.append(item.getName()).append(" x").append(qty).append(", ");
        }
        if (taskDesc.length() > 2) taskDesc.setLength(taskDesc.length() - 2); // remove last comma and space

        Task foodOrderTask = new Task(
                taskDesc.toString(),
                "Unassigned", // assignedTo
                "High",       // priority
                LocalDate.now(), // due today
                "Kitchen"     // department
        );
        TaskUtil.addTask(foodOrderTask);
        // ---------------------------------------------------------------------

        // Update inventory and remove zero-quantity items
        FoodItem.updateQuantities(selectedQuantities);

        // Reload the menu to reflect new quantities and remove zero-quantity items
        refreshMenu();

        String resultMsg = "Order Successful! Task sent to Kitchen.";
        if (change > 0.0) {
            resultMsg += "\nPlease give change: $" + String.format("%.2f", change);
        }
        taOrderSummary.setText(resultMsg + "\n\n" + sb);

        selectedItems.clear();
        selectedQuantities.clear();
        lvSelected.getItems().clear();
        lvMenu.getSelectionModel().clearSelection();
        tfClientName.clear();
        tfRoomNumber.clear();
        tfAmountPaid.clear();
        updateTotal();
    }

    @FXML
    private void goBack() {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.showAndWait();
    }
}