package com.example.hotel;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;

public class Main extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        try {
            if (!isInitialized()) {
                loadScene("HotelSetup.fxml");
            } else {
                loadScene("MainMenu.fxml");
            }
            primaryStage.setTitle("Hotel Management System");
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Optionally show an alert or error dialog here
        }
    }

    public static void loadScene(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("/com/example/hotel/" + fxml));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        // Do not call primaryStage.show() here, only in start()
    }

    private boolean isInitialized() {
        File file = new File("rooms.dat");
        return file.exists();
    }

    public static void main(String[] args) {
        launch(args);
    }
}