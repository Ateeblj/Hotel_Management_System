package com.example.hotel;

import Backend.Room;
import Backend.Client;
import Backend.ClientFileUtil;
import Backend.FeeSlip;
import Backend.FeeSlipUtil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;

import java.io.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class BookRoomController {

    @FXML
    private Spinner<Integer> numRoomsSpinner;
    @FXML
    private TextField roomNumberField; // For backward compatibility
    @FXML
    private Spinner<Integer> nightsSpinner;
    @FXML
    private TextField nameField;
    @FXML
    private TextField cnicField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField emailField;
    @FXML
    private Label totalCostLabel;
    @FXML
    private TextField paymentField;

    @FXML
    private VBox vbRoomNumbers;

    private static final String ROOMS_FILE = "rooms.dat";
    private List<TextField> roomNumberFields = new ArrayList<>();

    // Store the latest selected rooms for reactivity
    private List<Room> selectedRooms = new ArrayList<>();

    @FXML
    public void initialize() {
        numRoomsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 2, 1));
        nightsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 30, 1));
        totalCostLabel.setText("0");
        nightsSpinner.valueProperty().addListener((obs, oldVal, newVal) -> updateTotalCost());
        numRoomsSpinner.valueProperty().addListener((obs, oldVal, newVal) -> {
            updateTotalCost();
            updateRoomNumberFields();
        });
        // React to room number field changes to update cost
        updateRoomNumberFields();
    }

    // Helper to get Room object by number
    private Room getRoomByNumber(String roomNumber, List<Room> allRooms) {
        for (Room r : allRooms) {
            if (r.getRoomNumber().equals(roomNumber)) {
                return r;
            }
        }
        return null;
    }

    private void updateTotalCost() {
        int nights = nightsSpinner.getValue();
        int rooms = numRoomsSpinner.getValue();
        double total = 0.0;

        List<Room> allRooms = loadRoomsFromFile();
        List<String> enteredRoomNumbers = new ArrayList<>();
        if (roomNumberFields.size() > 0) {
            for (TextField tf : roomNumberFields) {
                String rn = tf.getText().trim();
                if (!rn.isEmpty()) enteredRoomNumbers.add(rn);
            }
        } else {
            String rn = roomNumberField.getText().trim();
            if (!rn.isEmpty()) enteredRoomNumbers.add(rn);
        }
        selectedRooms.clear();

        for (String roomNumber : enteredRoomNumbers) {
            Room room = getRoomByNumber(roomNumber, allRooms);
            if (room != null) {
                total += room.getPricePerNight() * nights;
                selectedRooms.add(room);
            }
        }
        // If not all numbers are filled, fallback to a default price per room
        if (enteredRoomNumbers.size() < rooms) {
            int missing = rooms - enteredRoomNumbers.size();
            double defaultRoomPrice = 10000.0;
            total += missing * defaultRoomPrice * nights;
        }
        totalCostLabel.setText(String.format("%.2f", total));
    }

    private void updateRoomNumberFields() {
        if (vbRoomNumbers == null) return;
        vbRoomNumbers.getChildren().clear();
        roomNumberFields.clear();
        int numRooms = numRoomsSpinner.getValue();
        if (numRooms > 2) numRooms = 2;
        for (int i = 0; i < numRooms; i++) {
            TextField tf = new TextField();
            tf.setPromptText("Room Number #" + (i + 1));
            // Update cost on field changes
            tf.textProperty().addListener((obs, oldVal, newVal) -> updateTotalCost());
            vbRoomNumbers.getChildren().add(tf);
            roomNumberFields.add(tf);
        }
    }

    @FXML
    private void onConfirmBooking(ActionEvent event) {
        if (nameField.getText().isEmpty() ||
                cnicField.getText().isEmpty() ||
                addressField.getText().isEmpty() ||
                phoneField.getText().isEmpty() ||
                emailField.getText().isEmpty()) {
            showAlert("Please fill in all required fields.");
            return;
        }

        ArrayList<String> enteredRoomNumbers = new ArrayList<>();
        boolean missingRoomNumber = false;
        if (roomNumberFields.size() > 0) {
            for (TextField tf : roomNumberFields) {
                String rn = tf.getText().trim();
                if (rn.isEmpty()) {
                    missingRoomNumber = true;
                }
                enteredRoomNumbers.add(rn);
            }
        } else {
            String rn = roomNumberField.getText().trim();
            if (rn.isEmpty()) {
                missingRoomNumber = true;
            }
            enteredRoomNumbers.add(rn);
        }
        if (missingRoomNumber) {
            showAlert("Please enter all room numbers.");
            return;
        }
        if (enteredRoomNumbers.size() > 2) {
            showAlert("You can book a maximum of 2 rooms at a time.");
            return;
        }

        String cnic = cnicField.getText().trim();
        if (!cnic.matches("\\d{13}")) {
            showAlert("CNIC must be exactly 13 digits.");
            return;
        }
        String phone = phoneField.getText().trim();
        if (!phone.matches("\\d{11}")) {
            showAlert("Phone number must be exactly 11 digits.");
            return;
        }
        String email = emailField.getText().trim();
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            showAlert("Invalid email format.");
            return;
        }
        String city = addressField.getText().trim();
        if (!city.matches("[A-Za-z ]+")) {
            showAlert("City must only contain letters and spaces.");
            return;
        }

        List<Room> allRooms = loadRoomsFromFile();
        int nights = nightsSpinner.getValue();

        // Validate & fetch selected rooms, calculate total cost precisely
        List<Room> roomsToBook = new ArrayList<>();
        double totalCost = 0.0;
        for (String roomNumber : enteredRoomNumbers) {
            Room found = getRoomByNumber(roomNumber, allRooms);
            if (found == null) {
                showAlert("Room " + roomNumber + " does not exist.");
                return;
            }
            if (found.isOccupied()) {
                showAlert("Room " + roomNumber + " is already occupied.");
                return;
            }
            roomsToBook.add(found);
            totalCost += found.getPricePerNight() * nights;
        }

        // Payment
        double payment;
        try {
            payment = Double.parseDouble(paymentField.getText());
        } catch (NumberFormatException e) {
            showAlert("Invalid payment amount.");
            return;
        }
        if (payment < totalCost) {
            showAlert("Insufficient payment.");
            return;
        }

        // Book all rooms
        for (Room r : roomsToBook) {
            r.bookRoom(nights);
        }
        saveRoomsToFile(allRooms);

        // Save a separate client record and fee slip for each room booked
        String name = nameField.getText().trim();
        String address = addressField.getText().trim();
        int roomsCount = enteredRoomNumbers.size();
        // Calculate per-room cost according to its price
        for (Room r : roomsToBook) {
            double perRoomCost = r.getPricePerNight() * nights;
            Client client = new Client(name, cnic, phone, email, r.getRoomNumber(), address, nights, perRoomCost);
            ClientFileUtil.addClient(client);

            FeeSlip slip = new FeeSlip(
                    name,
                    r.getRoomNumber(),
                    perRoomCost,
                    LocalDateTime.now(),
                    "Cash"
            );
            FeeSlipUtil.saveFeeSlip(slip);
        }

        showAlert("Booking Confirmed! Change: " + String.format("%.2f", payment - totalCost));
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void backToClientMenu(ActionEvent event) {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onBack() {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void saveRoomsToFile(List<Room> rooms) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ROOMS_FILE))) {
            oos.writeObject(rooms);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private List<Room> loadRoomsFromFile() {
        File file = new File(ROOMS_FILE);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Room>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}