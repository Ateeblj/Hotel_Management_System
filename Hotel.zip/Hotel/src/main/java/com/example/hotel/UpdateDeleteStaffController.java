package com.example.hotel;

import Backend.Staff;
import Backend.StaffManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class UpdateDeleteStaffController {

    @FXML private TableView<Staff> tableStaff;
    @FXML private TableColumn<Staff, String> colId;
    @FXML private TableColumn<Staff, String> colName;
    @FXML private TableColumn<Staff, String> colRole;
    @FXML private TableColumn<Staff, String> colStatus;
    @FXML private TableColumn<Staff, String> colContact;
    @FXML private Button btnUpdate;
    @FXML private Button btnDelete;
    @FXML private Button btnBack;
    @FXML private TextField txtSearchStaff;
    @FXML private Button btnSearchStaff;

    private ObservableList<Staff> staffData = FXCollections.observableArrayList();
    private ObservableList<Staff> allStaffData = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getId()));
        colName.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getName()));
        colRole.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getRole()));
        colStatus.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
        colContact.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getContactInfo()));

        loadStaffTable();

        btnUpdate.setOnAction(e -> handleUpdateStaff());
        btnDelete.setOnAction(e -> handleDeleteStaff());
        btnBack.setOnAction(e -> handleBack());
        btnSearchStaff.setOnAction(e -> searchStaff());
    }

    private void loadStaffTable() {
        List<Staff> staffList = StaffManager.loadStaff();
        allStaffData.setAll(staffList);
        staffData.setAll(staffList);
        tableStaff.setItems(staffData);
    }

    private void searchStaff() {
        String query = txtSearchStaff.getText().toLowerCase().trim();
        if (query.isEmpty()) {
            staffData.setAll(allStaffData);
            return;
        }
        ObservableList<Staff> filtered = allStaffData.filtered(staff ->
                staff.getId().toLowerCase().contains(query) ||
                        staff.getName().toLowerCase().contains(query) ||
                        staff.getRole().toLowerCase().contains(query) ||
                        staff.getStatus().toLowerCase().contains(query) ||
                        staff.getContactInfo().toLowerCase().contains(query)
        );
        staffData.setAll(filtered);
    }

    // ...rest of your methods unchanged...
    private void handleUpdateStaff() {
        Staff selected = tableStaff.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a staff member to update.");
            return;
        }

        TextInputDialog dialog = new TextInputDialog(selected.getStatus());
        dialog.setTitle("Update Status");
        dialog.setHeaderText("Update staff status for: " + selected.getName());
        dialog.setContentText("Enter new status (New / Active / Left):");

        dialog.showAndWait().ifPresent(newStatus -> {
            if (!newStatus.equalsIgnoreCase("New") &&
                    !newStatus.equalsIgnoreCase("Active") &&
                    !newStatus.equalsIgnoreCase("Left")) {
                showAlert("Status must be New, Active, or Left.");
                return;
            }
            selected.setStatus(newStatus);
            StaffManager.updateStaff(selected);
            loadStaffTable();
            showAlert("Status updated successfully.");
        });
    }

    private void handleDeleteStaff() {
        Staff selected = tableStaff.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a staff member to delete.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete staff " + selected.getName() + "?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                StaffManager.deleteStaff(selected.getId());
                loadStaffTable();
                showAlert("Staff deleted successfully.");
            }
        });
    }

    private void handleBack() {
        try {
            Main.loadScene("StaffMenu.fxml");
        } catch (Exception e) {
            showAlert("Failed to go back: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.showAndWait();
    }
}