package com.example.hotel;

import Backend.Client;
import Backend.ClientFileUtil;
import Backend.Feedback;
import Backend.FeeSlipUtil;
import Backend.FeeSlip;
import Backend.Staff;
import Backend.StaffManager;
import Backend.Task;
import Backend.TaskUtil;
import Backend.FoodItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.print.PrinterJob;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

public class ManagerPanelController {

    @FXML private TabPane tabPane;
    @FXML private Tab tabClients;
    @FXML private Tab tabFeedback;
    @FXML private Tab tabFeeSlips;
    @FXML private Tab tabTasks;
    @FXML private Tab tabStaff;
    @FXML private Tab tabFood;

    @FXML private Button btnResetSystem;

    @FXML private TableView<Client> tableClients;
    @FXML private TableView<Feedback.FeedbackRecord> tableFeedback;
    @FXML private TableView<FeeSlip> tableFeeSlips;
    @FXML private TableView<Task> tableTasks;

    // Staff Management
    @FXML private TableView<Staff> tableStaff;
    @FXML private TableColumn<Staff, String> colStaffId;
    @FXML private TableColumn<Staff, String> colStaffName;
    @FXML private TableColumn<Staff, String> colStaffRole;
    @FXML private TableColumn<Staff, String> colStaffStatus;
    @FXML private TableColumn<Staff, String> colStaffContact;
    @FXML private Button btnAddStaff;
    @FXML private Button btnEditStaff;
    @FXML private Button btnDeleteStaff;

    // Food Management
    @FXML private TableView<FoodItem> tableFood;
    @FXML private TableColumn<FoodItem, String> colFoodName;
    @FXML private TableColumn<FoodItem, Double> colFoodPrice;
    @FXML private TableColumn<FoodItem, Integer> colFoodQuantity;
    @FXML private TextField txtFoodName;
    @FXML private TextField txtFoodPrice;
    @FXML private TextField txtFoodQuantity;
    @FXML private Button btnAddFood;
    @FXML private Button btnUpdateFood;
    @FXML private Button btnDeleteFood;

    // Client Columns
    @FXML private TableColumn<Client, String> colClientName;
    @FXML private TableColumn<Client, String> colClientCnic;
    @FXML private TableColumn<Client, String> colClientRoom;
    @FXML private TableColumn<Client, String> colClientPhone;
    @FXML private TableColumn<Client, String> colClientEmail;

    // Feedback Columns
    @FXML private TableColumn<Feedback.FeedbackRecord, String> colFbClientName;
    @FXML private TableColumn<Feedback.FeedbackRecord, String> colFbRoom;
    @FXML private TableColumn<Feedback.FeedbackRecord, Integer> colFbRating;
    @FXML private TableColumn<Feedback.FeedbackRecord, String> colFbComments;

    // FeeSlip Columns
    @FXML private TableColumn<FeeSlip, String> colSlipClientName;
    @FXML private TableColumn<FeeSlip, String> colSlipRoom;
    @FXML private TableColumn<FeeSlip, String> colSlipAmount;
    @FXML private TableColumn<FeeSlip, String> colSlipDate;
    @FXML private TableColumn<FeeSlip, String> colSlipMethod;

    // Task Columns
    @FXML private TableColumn<Task, String> colTaskDescription;
    @FXML private TableColumn<Task, String> colTaskAssignedTo;
    @FXML private TableColumn<Task, String> colTaskPriority;
    @FXML private TableColumn<Task, LocalDate> colTaskDueDate;
    @FXML private TableColumn<Task, String> colTaskStatus;
    @FXML private TableColumn<Task, String> colTaskDepartment;
    @FXML private TableColumn<Task, String> colTaskComments;

    // Task Controls
    @FXML private TextField txtTaskDescription;
    @FXML private ComboBox<String> comboTaskAssignedTo;
    @FXML private ComboBox<String> comboTaskPriority;
    @FXML private DatePicker dateTaskDue;
    @FXML private ComboBox<String> comboTaskDepartment;
    @FXML private Button btnAssignTask;
    @FXML private Button btnEditTask;
    @FXML private Button btnMarkTaskComplete;
    @FXML private Button btnDeleteTask;

    @FXML private Button btnBack;

    // --- Search, Edit, and Print Controls ---
    @FXML private TextField txtClientSearch;
    @FXML private Button btnClientSearch;
    @FXML private Button btnEditClient;
    @FXML private Button btnPrintClients;

    @FXML private TextField txtFeedbackSearch;
    @FXML private Button btnFeedbackSearch;

    @FXML private TextField txtFeeSlipSearch;
    @FXML private Button btnFeeSlipSearch;
    @FXML private Button btnPrintFeeSlips;

    // --- ObservableLists to keep full data for search reset ---
    private ObservableList<Client> allClients = FXCollections.observableArrayList();
    private ObservableList<Feedback.FeedbackRecord> allFeedback = FXCollections.observableArrayList();
    private ObservableList<FeeSlip> allFeeSlips = FXCollections.observableArrayList();

    private String managerNameFromFile = "";
    private String managerPasswordFromFile = "";

    private void readManagerCredentials() {
        try (BufferedReader br = new BufferedReader(new FileReader("credentials.dat"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("managerName=")) {
                    managerNameFromFile = line.substring("managerName=".length());
                } else if (line.startsWith("managerPassword=")) {
                    managerPasswordFromFile = line.substring("managerPassword=".length());
                }
            }
        } catch (IOException e) {
            // Optionally show error or create credentials
        }
    }

    @FXML
    private void initialize() {
        btnResetSystem.setOnAction(e -> handleResetSystem());
        readManagerCredentials();
        boolean authenticated = showManagerLoginDialog();
        if (!authenticated) {
            Stage stage = (Stage) tabPane.getScene().getWindow();
            stage.close();
            return;
        }

        setupClientTable();
        setupFeedbackTable();
        setupFeeSlipTable();
        setupTaskTable();
        setupTaskControls();

        setupStaffTable();
        loadStaffTable();

        setupFoodTable();
        loadFoodTable();

        loadClientTable();
        loadFeedbackTable();
        loadFeeSlipTable();
        loadTaskTable();

        btnBack.setOnAction(e -> handleBack());
        btnAssignTask.setOnAction(e -> assignTask());
        btnEditTask.setOnAction(e -> editTask());
        btnMarkTaskComplete.setOnAction(e -> markTaskComplete());
        btnDeleteTask.setOnAction(e -> deleteTask());

        btnAddStaff.setOnAction(e -> handleAddStaff());
        btnEditStaff.setOnAction(e -> handleEditStaff());
        btnDeleteStaff.setOnAction(e -> handleDeleteStaff());

        btnAddFood.setOnAction(e -> handleAddFood());
        btnUpdateFood.setOnAction(e -> handleUpdateFood());
        btnDeleteFood.setOnAction(e -> handleDeleteFood());

        if (btnClientSearch != null) btnClientSearch.setOnAction(e -> searchClients());
        if (btnEditClient != null) btnEditClient.setOnAction(e -> editSelectedClient());
        if (btnPrintClients != null) btnPrintClients.setOnAction(e -> printClients());

        if (btnFeedbackSearch != null) btnFeedbackSearch.setOnAction(e -> searchFeedback());

        if (btnFeeSlipSearch != null) btnFeeSlipSearch.setOnAction(e -> searchFeeSlips());
        if (btnPrintFeeSlips != null) btnPrintFeeSlips.setOnAction(e -> printFeeSlips());

        tableTasks.getSelectionModel().selectedItemProperty().addListener((obs, oldTask, newTask) -> populateTaskFieldsForEdit(newTask));
    }

    // --- Tooltip Cell Factory for Long Text ---
    private <T> void setTooltipCellFactory(TableColumn<T, String> col) {
        col.setCellFactory(tc -> {
            TableCell<T, String> cell = new TableCell<T, String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(item);
                    if (item != null && !empty) {
                        setTooltip(new Tooltip(item));
                    } else {
                        setTooltip(null);
                    }
                }
            };
            return cell;
        });
    }

    // --- Table Setup Methods ---
    private void setupTaskTable() {
        colTaskDescription.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDescription()));
        colTaskAssignedTo.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getAssignedTo()));
        colTaskPriority.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getPriority()));
        colTaskDueDate.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().getDueDate()));
        colTaskStatus.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getStatus()));
        colTaskDepartment.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDepartment()));
        colTaskComments.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getComments()));
        setTooltipCellFactory(colTaskDescription);
        setTooltipCellFactory(colTaskComments);
        setTooltipCellFactory(colTaskDepartment);
    }

    private void setupFeedbackTable() {
        colFbClientName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().clientName));
        colFbRoom.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().roomNumber));
        colFbRating.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().rating));
        colFbComments.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().comments));
        setTooltipCellFactory(colFbComments);
    }

    private void setupClientTable() {
        colClientName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getName()));
        colClientCnic.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCnic()));
        colClientRoom.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getBookedRoomNumber()));
        colClientPhone.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getPhoneNumber()));
        colClientEmail.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getEmail()));
        setTooltipCellFactory(colClientName);
        setTooltipCellFactory(colClientEmail);
    }

    private void setupFeeSlipTable() {
        colSlipClientName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getClientName()));
        colSlipRoom.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getRoomNumber()));
        colSlipAmount.setCellValueFactory(cell -> new SimpleStringProperty(String.format("%.2f", cell.getValue().getAmountPaid())));
        colSlipDate.setCellValueFactory(cell -> new SimpleStringProperty(
                cell.getValue().getPaymentDate() != null ? cell.getValue().getPaymentDate().toString() : ""));
        colSlipMethod.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getPaymentMethod()));
    }

    private void setupFoodTable() {
        colFoodName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getName()));
        colFoodPrice.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().getPrice()));
        colFoodQuantity.setCellValueFactory(cell -> new javafx.beans.property.SimpleObjectProperty<>(cell.getValue().getQuantity()));
        tableFood.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtFoodName.setText(newSel.getName());
                txtFoodPrice.setText(String.valueOf(newSel.getPrice()));
                txtFoodQuantity.setText(String.valueOf(newSel.getQuantity()));
            }
        });
    }

    private void setupStaffTable() {
        colStaffId.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getId()));
        colStaffName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getName()));
        colStaffRole.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getRole()));
        colStaffStatus.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getStatus()));
        colStaffContact.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getContactInfo()));
    }

    private void setupTaskControls() {
        comboTaskPriority.setItems(FXCollections.observableArrayList("Low", "Medium", "High"));
        comboTaskDepartment.setItems(FXCollections.observableArrayList("Housekeeping", "Maintenance", "Reception", "Kitchen", "Other"));
        List<Staff> staffList = StaffManager.loadStaff();
        ObservableList<String> staffNames = FXCollections.observableArrayList();
        for (Staff s : staffList) {
            if ("Active".equalsIgnoreCase(s.getStatus())) {
                staffNames.add(s.getName());
            }
        }
        staffNames.add("Unassigned");
        comboTaskAssignedTo.setItems(staffNames);
    }

    // --- Load Data Methods ---
    private void loadTaskTable() {
        List<Task> tasks = TaskUtil.loadTasks();
        tableTasks.setItems(FXCollections.observableArrayList(tasks));
    }

    private void loadClientTable() {
        List<Client> clients = ClientFileUtil.loadClients();
        allClients.setAll(clients);
        tableClients.setItems(allClients);
    }

    private void loadFeedbackTable() {
        List<Feedback.FeedbackRecord> feedbackList = Feedback.loadFeedbackRecordsStatic();
        allFeedback.setAll(feedbackList);
        tableFeedback.setItems(allFeedback);
    }

    private void loadFeeSlipTable() {
        List<FeeSlip> slips = FeeSlipUtil.loadFeeSlips();
        allFeeSlips.setAll(slips);
        tableFeeSlips.setItems(allFeeSlips);
    }

    private void loadStaffTable() {
        List<Staff> staffList = StaffManager.loadStaff();
        tableStaff.setItems(FXCollections.observableArrayList(staffList));
    }

    private void loadFoodTable() {
        List<FoodItem> items = FoodItem.loadFoodItems();
        tableFood.setItems(FXCollections.observableArrayList(items));
    }

    // --- Task Actions ---
    private void assignTask() {
        String description = txtTaskDescription.getText().trim();
        String assignedTo = comboTaskAssignedTo.getValue();
        String priority = comboTaskPriority.getValue();
        LocalDate dueDate = dateTaskDue.getValue();
        String department = comboTaskDepartment.getValue();

        if (description.isEmpty() || assignedTo == null || priority == null || dueDate == null || department == null) {
            showAlert("Fill in all fields to assign a task.");
            return;
        }
        if (!"Unassigned".equalsIgnoreCase(assignedTo)) {
            Staff assignedStaff = StaffManager.findStaffByName(assignedTo);
            if (assignedStaff == null || !"Active".equalsIgnoreCase(assignedStaff.getStatus())) {
                showAlert("Cannot assign task. The selected staff is not active.");
                setupTaskControls();
                return;
            }
        }

        Task newTask = new Task(description, assignedTo, priority, dueDate, department);
        TaskUtil.addTask(newTask);
        loadTaskTable();
        clearTaskInputs();
    }

    private void editTask() {
        Task selected = tableTasks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a task to edit.");
            return;
        }
        String description = txtTaskDescription.getText().trim();
        String assignedTo = comboTaskAssignedTo.getValue();
        String priority = comboTaskPriority.getValue();
        LocalDate dueDate = dateTaskDue.getValue();
        String department = comboTaskDepartment.getValue();

        if (description.isEmpty() || assignedTo == null || priority == null || dueDate == null || department == null) {
            showAlert("Fill in all fields to edit the task.");
            return;
        }

        Task updatedTask = new Task(description, assignedTo, priority, dueDate, department);
        updatedTask.setId(selected.getId()); // preserve original Task ID
        updatedTask.setStatus(selected.getStatus());
        updatedTask.setComments(selected.getComments());

        if (!"Unassigned".equals(assignedTo) && "Unassigned".equals(selected.getStatus())) {
            updatedTask.setStatus("Assigned");
        }
        if ("Unassigned".equals(assignedTo)) {
            updatedTask.setStatus("Unassigned");
        }

        TaskUtil.updateTask(updatedTask);
        loadTaskTable();
        clearTaskInputs();
        showInfo("Task details updated.");
    }

    private void markTaskComplete() {
        Task selected = tableTasks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a task to mark as completed.");
            return;
        }
        selected.setStatus("Completed");
        TaskUtil.updateTask(selected);
        loadTaskTable();
    }

    private void deleteTask() {
        Task selected = tableTasks.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a task to delete.");
            return;
        }
        TaskUtil.deleteTask(selected);
        loadTaskTable();
    }

    private void clearTaskInputs() {
        txtTaskDescription.clear();
        comboTaskAssignedTo.setValue(null);
        comboTaskPriority.setValue(null);
        dateTaskDue.setValue(null);
        comboTaskDepartment.setValue(null);
    }

    private void populateTaskFieldsForEdit(Task task) {
        if (task != null) {
            txtTaskDescription.setText(task.getDescription());
            comboTaskAssignedTo.setValue(task.getAssignedTo());
            comboTaskPriority.setValue(task.getPriority());
            dateTaskDue.setValue(task.getDueDate());
            comboTaskDepartment.setValue(task.getDepartment());
        }
    }

    // --- Client, Feedback, FeeSlip Actions ---
    private void searchClients() {
        String keyword = txtClientSearch.getText() != null ? txtClientSearch.getText().trim().toLowerCase() : "";
        if (keyword.isEmpty()) {
            tableClients.setItems(allClients);
            return;
        }
        ObservableList<Client> filtered = allClients.stream()
                .filter(client ->
                        client.getName().toLowerCase().contains(keyword) ||
                                client.getCnic().contains(keyword) ||
                                client.getBookedRoomNumber().contains(keyword) ||
                                client.getPhoneNumber().contains(keyword) ||
                                client.getEmail().toLowerCase().contains(keyword)
                )
                .collect(Collectors.toCollection(FXCollections::observableArrayList));
        tableClients.setItems(filtered);
    }

    private void editSelectedClient() {
        Client selected = tableClients.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a client to edit.");
            return;
        }
        Client edited = showClientEditDialog(selected);
        if (edited != null) {
            ClientFileUtil.updateClient(selected.getCnic(), edited);
            loadClientTable();
            showInfo("Client details updated.");
        }
    }

    private Client showClientEditDialog(Client clientEdit) {
        Dialog<Client> dialog = new Dialog<>();
        dialog.setTitle("Edit Client");

        Label lblName = new Label("Name:");
        TextField tfName = new TextField(clientEdit.getName());
        Label lblCnic = new Label("CNIC:");
        TextField tfCnic = new TextField(clientEdit.getCnic());
        Label lblRoom = new Label("Room:");
        TextField tfRoom = new TextField(clientEdit.getBookedRoomNumber());
        Label lblPhone = new Label("Phone:");
        TextField tfPhone = new TextField(clientEdit.getPhoneNumber());
        Label lblEmail = new Label("Email:");
        TextField tfEmail = new TextField(clientEdit.getEmail());

        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.add(lblName, 0, 0); grid.add(tfName, 1, 0);
        grid.add(lblCnic, 0, 1); grid.add(tfCnic, 1, 1);
        grid.add(lblRoom, 0, 2); grid.add(tfRoom, 1, 2);
        grid.add(lblPhone, 0, 3); grid.add(tfPhone, 1, 3);
        grid.add(lblEmail, 0, 4); grid.add(tfEmail, 1, 4);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String name = tfName.getText().trim();
                String cnic = tfCnic.getText().trim();
                String room = tfRoom.getText().trim();
                String phone = tfPhone.getText().trim();
                String email = tfEmail.getText().trim();
                if (name.isEmpty() || cnic.isEmpty() || room.isEmpty() || phone.isEmpty() || email.isEmpty()) {
                    showAlert("All fields are required.");
                    return null;
                }
                return new Client(name, cnic, phone, email, room, clientEdit.getAddress(), clientEdit.getNights(), clientEdit.getTotalCost());
            }
            return null;
        });

        Optional<Client> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private void printClients() {
        ObservableList<Client> clients = tableClients.getItems();
        if (clients == null || clients.isEmpty()) {
            showInfo("No client data to print.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Clients List:\n");
        sb.append("-------------------------------------------------------------\n");
        for (Client client : clients) {
            sb.append("Name: ").append(client.getName())
                    .append(" | CNIC: ").append(client.getCnic())
                    .append(" | Room: ").append(client.getBookedRoomNumber())
                    .append(" | Phone: ").append(client.getPhoneNumber())
                    .append(" | Email: ").append(client.getEmail())
                    .append("\n");
        }
        printString(sb.toString());
    }

    private void searchFeedback() {
        String keyword = txtFeedbackSearch.getText() != null ? txtFeedbackSearch.getText().trim().toLowerCase() : "";
        if (keyword.isEmpty()) {
            tableFeedback.setItems(allFeedback);
            return;
        }
        ObservableList<Feedback.FeedbackRecord> filtered = allFeedback.stream()
                .filter(fb ->
                        fb.clientName.toLowerCase().contains(keyword) ||
                                fb.roomNumber.toLowerCase().contains(keyword) ||
                                String.valueOf(fb.rating).contains(keyword) ||
                                (fb.comments != null && fb.comments.toLowerCase().contains(keyword)))
                .collect(Collectors.toCollection(FXCollections::observableArrayList));
        tableFeedback.setItems(filtered);
    }

    private void searchFeeSlips() {
        String keyword = txtFeeSlipSearch.getText() != null ? txtFeeSlipSearch.getText().trim().toLowerCase() : "";
        if (keyword.isEmpty()) {
            tableFeeSlips.setItems(allFeeSlips);
            return;
        }
        ObservableList<FeeSlip> filtered = allFeeSlips.stream()
                .filter(slip ->
                        slip.getClientName().toLowerCase().contains(keyword) ||
                                slip.getRoomNumber().toLowerCase().contains(keyword) ||
                                String.format("%.2f", slip.getAmountPaid()).contains(keyword) ||
                                (slip.getPaymentDate() != null && slip.getPaymentDate().toString().contains(keyword)) ||
                                slip.getPaymentMethod().toLowerCase().contains(keyword)
                )
                .collect(Collectors.toCollection(FXCollections::observableArrayList));
        tableFeeSlips.setItems(filtered);
    }

    private void printFeeSlips() {
        ObservableList<FeeSlip> slips = tableFeeSlips.getItems();
        if (slips == null || slips.isEmpty()) {
            showInfo("No fee slips to print.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fee Slips:\n");
        sb.append("-------------------------------------------------------------\n");
        for (FeeSlip slip : slips) {
            sb.append("Client: ").append(slip.getClientName())
                    .append(" | Room: ").append(slip.getRoomNumber())
                    .append(" | Amount: ").append(String.format("%.2f", slip.getAmountPaid()))
                    .append(" | Date: ").append(slip.getPaymentDate())
                    .append(" | Method: ").append(slip.getPaymentMethod())
                    .append("\n");
        }
        printString(sb.toString());
    }

    // --- Staff Actions ---
    private void handleAddStaff() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddStaff.fxml"));
            Parent parent = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Add Staff");
            stage.setScene(new Scene(parent));
            stage.showAndWait();

            AddStaffController controller = loader.getController();
            Staff newStaff = controller.getCreatedStaff();
            if (newStaff != null) {
                loadStaffTable();
                showInfo("Staff member added.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleEditStaff() {
        Staff selected = tableStaff.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a staff member to edit.");
            return;
        }
        Staff updated = showStaffDialog(selected);
        if (updated != null) {
            updated.setId(selected.getId());
            StaffManager.updateStaff(updated);
            loadStaffTable();
            showInfo("Staff details updated.");
        }
    }

    private void handleDeleteStaff() {
        Staff selected = tableStaff.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a staff member to delete.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete staff: " + selected.getName() + "?", ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Staff Deletion");
        Optional<ButtonType> res = confirm.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.YES) {
            StaffManager.deleteStaff(selected.getId());
            loadStaffTable();
            showInfo("Staff deleted.");
        }
    }

    private Staff showStaffDialog(Staff staffEdit) {
        Dialog<Staff> dialog = new Dialog<>();
        dialog.setTitle(staffEdit == null ? "Add Staff" : "Edit Staff");

        Label lblName = new Label("Name:");
        TextField tfName = new TextField();
        Label lblRole = new Label("Role:");
        TextField tfRole = new TextField();
        Label lblStatus = new Label("Status:");
        ComboBox<String> cbStatus = new ComboBox<>(FXCollections.observableArrayList("Active", "On Leave", "Left"));
        Label lblContact = new Label("Contact Info:");
        TextField tfContact = new TextField();

        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.add(lblName, 0, 0); grid.add(tfName, 1, 0);
        grid.add(lblRole, 0, 1); grid.add(tfRole, 1, 1);
        grid.add(lblStatus, 0, 2); grid.add(cbStatus, 1, 2);
        grid.add(lblContact, 0, 3); grid.add(tfContact, 1, 3);

        if (staffEdit != null) {
            tfName.setText(staffEdit.getName());
            tfRole.setText(staffEdit.getRole());
            cbStatus.setValue(staffEdit.getStatus());
            tfContact.setText(staffEdit.getContactInfo());
        } else {
            cbStatus.setValue("Active");
        }

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String name = tfName.getText().trim();
                String role = tfRole.getText().trim();
                String status = cbStatus.getValue();
                String contact = tfContact.getText().trim();
                if (name.isEmpty() || role.isEmpty() || status == null || contact.isEmpty()) {
                    showAlert("All fields are required.");
                    return null;
                }
                return new Staff(null, name, role, status, contact);
            }
            return null;
        });

        Optional<Staff> result = dialog.showAndWait();
        return result.orElse(null);
    }

    // --- Food Actions ---
    private void handleAddFood() {
        String name = txtFoodName.getText().trim();
        String priceStr = txtFoodPrice.getText().trim();
        String quantityStr = txtFoodQuantity.getText().trim();
        if (name.isEmpty() || priceStr.isEmpty() || quantityStr.isEmpty()) {
            showAlert("All fields are required.");
            return;
        }
        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            showAlert("Invalid number format.");
            return;
        }
        FoodItem.addFoodItem(new FoodItem(name, price, quantity));
        loadFoodTable();
        clearFoodFields();
    }

    private void handleUpdateFood() {
        FoodItem selected = tableFood.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select an item to update.");
            return;
        }
        String name = txtFoodName.getText().trim();
        String priceStr = txtFoodPrice.getText().trim();
        String quantityStr = txtFoodQuantity.getText().trim();
        if (name.isEmpty() || priceStr.isEmpty() || quantityStr.isEmpty()) {
            showAlert("All fields are required.");
            return;
        }
        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            showAlert("Invalid number format.");
            return;
        }
        boolean success = FoodItem.updateFoodItem(selected.getName(), new FoodItem(name, price, quantity));
        if (success) {
            loadFoodTable();
            clearFoodFields();
        } else {
            showAlert("Update failed. Item not found.");
        }
    }

    private void handleDeleteFood() {
        FoodItem selected = tableFood.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select an item to delete.");
            return;
        }
        boolean success = FoodItem.deleteFoodItem(selected.getName());
        if (success) {
            loadFoodTable();
            clearFoodFields();
        } else {
            showAlert("Delete failed. Item not found.");
        }
    }

    private void clearFoodFields() {
        txtFoodName.clear();
        txtFoodPrice.clear();
        txtFoodQuantity.clear();
    }

    // --- Printing ---
    private void printString(String text) {
        TextArea printArea = new TextArea(text);
        printArea.setWrapText(true);
        printArea.setPrefWidth(500);
        printArea.setPrefHeight(700);
        printArea.setMinHeight(Region.USE_PREF_SIZE);

        PrinterJob job = PrinterJob.createPrinterJob();
        if (job != null && job.showPrintDialog(tableClients.getScene().getWindow())) {
            boolean success = job.printPage(printArea);
            if (success) {
                job.endJob();
            }
        }
    }

    // --- Navigation & System ---
    private void handleBack() {
        try {
            Main.loadScene("StaffMenu.fxml");
        } catch (Exception e) {
            showAlert("Failed to go back: " + e.getMessage());
        }
    }

    private void handleResetSystem() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to reset the system? This will delete all hotel data and close the program.",
                ButtonType.YES, ButtonType.NO);
        alert.setTitle("Confirm System Reset");
        alert.setHeaderText("System Reset");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                File directory = new File(".");
                File[] files = directory.listFiles((dir, name) ->
                        name.endsWith(".dat") || name.endsWith(".txt"));

                if (files != null) {
                    for (File f : files) {
                        if (f.exists()) {
                            boolean deleted = f.delete();
                            if (!deleted) {
                                System.out.println("Could not delete file: " + f.getName());
                            }
                        }
                    }
                }

                Alert doneAlert = new Alert(Alert.AlertType.INFORMATION,
                        "System reset completed. The program will now close.", ButtonType.OK);
                doneAlert.showAndWait();
                System.exit(0);
            }
        });
    }

    private boolean showManagerLoginDialog() {
        Dialog<Boolean> dialog = new Dialog<>();
        dialog.setTitle("Manager Login");

        Label nameLabel = new Label("Manager Name:");
        TextField nameField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(passLabel, 0, 1);
        grid.add(passField, 1, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String inputName = nameField.getText().trim();
                String inputPass = passField.getText();
                if (inputName.equals(managerNameFromFile) && inputPass.equals(managerPasswordFromFile)) {
                    return true;
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Incorrect manager name or password.", ButtonType.OK);
                    alert.showAndWait();
                    return false;
                }
            }
            return false;
        });

        boolean loggedIn = dialog.showAndWait().orElse(false);
        return loggedIn;
    }

    // --- Alerts ---
    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.showAndWait();
    }
}