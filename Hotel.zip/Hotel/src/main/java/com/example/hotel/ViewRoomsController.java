package com.example.hotel;

import Backend.Room;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

import java.io.*;
import java.util.*;

public class ViewRoomsController {
    @FXML private ListView<String> lvRooms;
    private static final String ROOMS_FILE = "rooms.dat";

    @FXML
    private void initialize() {
        List<Room> allRooms = loadRoomsFromFile();
        List<String> available = new ArrayList<>();

        for (Room room : allRooms) {
            room.updateAvailability();
            if (!room.isOccupied()) {
                // Example: 101 - STANDARD - Single - PKR 3500.00/night
                String display = String.format(
                        "%s - %s - %s - PKR %.2f/night",
                        room.getRoomNumber(),
                        room.getRoomType(),
                        room.getBedType(),
                        room.getPricePerNight()
                );
                available.add(display);
            }
        }
        lvRooms.getItems().setAll(available);
        saveRoomsToFile(allRooms);
    }

    private void saveRoomsToFile(List<Room> rooms) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ROOMS_FILE))) {
            oos.writeObject(rooms);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void backToClientMenu(ActionEvent event) {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private List<Room> loadRoomsFromFile() {
        File file = new File(ROOMS_FILE);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Room>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}