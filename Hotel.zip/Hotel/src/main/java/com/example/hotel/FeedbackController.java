package com.example.hotel;

import Backend.Feedback;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class FeedbackController {

    @FXML private TextField tfClientName;
    @FXML private TextField tfRoomNumber;
    @FXML private ChoiceBox<Integer> cbRating;
    @FXML private TextArea taFeedback;
    @FXML private Button btnSubmit;
    @FXML private Label lblStatus;

    private Feedback feedbackSystem;

    @FXML
    private void initialize() {
        // Populate rating choices 1-5
        cbRating.getItems().addAll(1, 2, 3, 4, 5);
        cbRating.setValue(5); // default

        feedbackSystem = new Feedback();

        btnSubmit.setOnAction(e -> handleSubmit());
    }

    @FXML
    private void backToClientMenu(ActionEvent event) {
        try {
            Main.loadScene("ClientMenu.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void handleSubmit() {
        String clientName = tfClientName.getText().trim();
        String roomNumber = tfRoomNumber.getText().trim();
        String feedbackText = taFeedback.getText().trim();
        Integer rating = cbRating.getValue();

        if (clientName.isEmpty() || roomNumber.isEmpty() || feedbackText.isEmpty() || rating == null) {
            lblStatus.setText("Please fill all fields.");
            lblStatus.setTextFill(javafx.scene.paint.Color.RED);
            return;
        }

        feedbackSystem.collectFeedback(clientName, roomNumber, feedbackText, rating);

        lblStatus.setText("Feedback submitted! Thank you.");
        lblStatus.setTextFill(javafx.scene.paint.Color.GREEN);

        tfClientName.clear();
        tfRoomNumber.clear();
        taFeedback.clear();
        cbRating.setValue(5);
    }
}